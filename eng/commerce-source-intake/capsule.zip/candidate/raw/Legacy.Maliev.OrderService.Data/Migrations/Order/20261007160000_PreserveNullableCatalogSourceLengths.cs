using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Legacy.Maliev.OrderService.Data.Migrations.Order;

/// <inheritdoc />
public partial class PreserveNullableCatalogSourceLengths : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            SET LOCAL lock_timeout = '5s';
            SET LOCAL statement_timeout = '30s';
            LOCK TABLE public."Category", public."FileFormat" IN ACCESS EXCLUSIVE MODE;
            DO $guard$
            DECLARE definition text; expected text;
            BEGIN
                IF current_setting('server_encoding') <> 'UTF8' THEN RAISE EXCEPTION 'Catalog source encoding is incompatible.'; END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."Category" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Catalog source preflight row limit exceeded.';
                END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."FileFormat" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Catalog source preflight row limit exceeded.';
                END IF;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."Category"'::regclass AND attname = 'Name'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'varchar'::regtype AND atttypmod = 54 AND NOT attisdropped)
                    OR EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public."Category"'::regclass AND conname = 'CK_Category_Name_SourceLength') THEN
                    RAISE EXCEPTION 'Catalog source schema is incompatible.';
                END IF;
                IF EXISTS (SELECT 1 FROM public."Category" WHERE NOT (char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50)) THEN
                    RAISE EXCEPTION 'Catalog retained rows violate source string constraints.';
                END IF;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Name'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'varchar'::regtype AND atttypmod = 54 AND NOT attisdropped)
                    OR EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public."FileFormat"'::regclass AND conname = 'CK_FileFormat_Name_SourceLength') THEN
                    RAISE EXCEPTION 'Catalog source schema is incompatible.';
                END IF;
                IF EXISTS (SELECT 1 FROM public."FileFormat" WHERE NOT (char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50)) THEN
                    RAISE EXCEPTION 'Catalog retained rows violate source string constraints.';
                END IF;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Extension'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'varchar'::regtype AND atttypmod = 54 AND NOT attisdropped)
                    OR EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public."FileFormat"'::regclass AND conname = 'CK_FileFormat_Extension_SourceLength') THEN
                    RAISE EXCEPTION 'Catalog source schema is incompatible.';
                END IF;
                IF EXISTS (SELECT 1 FROM public."FileFormat" WHERE NOT (char_length("Extension") + char_length(regexp_replace("Extension" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50)) THEN
                    RAISE EXCEPTION 'Catalog retained rows violate source string constraints.';
                END IF;
            END $guard$;
            ALTER TABLE public."Category" ALTER COLUMN "Name" TYPE text;
            ALTER TABLE public."Category" ADD CONSTRAINT "CK_Category_Name_SourceLength" CHECK (char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50);
            ALTER TABLE public."FileFormat" ALTER COLUMN "Name" TYPE text;
            ALTER TABLE public."FileFormat" ADD CONSTRAINT "CK_FileFormat_Name_SourceLength" CHECK (char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50);
            ALTER TABLE public."FileFormat" ALTER COLUMN "Extension" TYPE text;
            ALTER TABLE public."FileFormat" ADD CONSTRAINT "CK_FileFormat_Extension_SourceLength" CHECK (char_length("Extension") + char_length(regexp_replace("Extension" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50);
            """);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            SET LOCAL lock_timeout = '5s';
            SET LOCAL statement_timeout = '30s';
            LOCK TABLE public."Category", public."FileFormat" IN ACCESS EXCLUSIVE MODE;
            DO $guard$
            DECLARE definition text; expected text;
            BEGIN
                IF current_setting('server_encoding') <> 'UTF8' THEN RAISE EXCEPTION 'Catalog source encoding is incompatible.'; END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."Category" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Catalog source preflight row limit exceeded.';
                END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."FileFormat" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Catalog source preflight row limit exceeded.';
                END IF;
                CREATE TEMP TABLE "__NullableCatalogSourceGuard" ("Name" text, "Extension" text,
                    CONSTRAINT "expected_Name" CHECK (char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50),
                    CONSTRAINT "expected_Extension" CHECK (char_length("Extension") + char_length(regexp_replace("Extension" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50)) ON COMMIT DROP;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."Category"'::regclass AND attname = 'Name'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'text'::regtype AND NOT attisdropped) THEN
                    RAISE EXCEPTION 'Catalog downgrade schema is incompatible.';
                END IF;
                SELECT pg_get_constraintdef(oid) INTO expected FROM pg_constraint
                    WHERE conrelid = 'pg_temp."__NullableCatalogSourceGuard"'::regclass AND conname = 'expected_Name';
                SELECT pg_get_constraintdef(oid) INTO definition FROM pg_constraint
                    WHERE conrelid = 'public."Category"'::regclass AND conname = 'CK_Category_Name_SourceLength' AND contype = 'c'
                    AND convalidated AND conislocal AND coninhcount = 0 AND NOT connoinherit
                    AND conkey = ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid = 'public."Category"'::regclass AND attname = 'Name')]::smallint[];
                IF definition IS NULL OR definition IS DISTINCT FROM expected THEN
                    RAISE EXCEPTION 'Catalog downgrade constraint is incompatible.';
                END IF;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Name'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'text'::regtype AND NOT attisdropped) THEN
                    RAISE EXCEPTION 'Catalog downgrade schema is incompatible.';
                END IF;
                SELECT pg_get_constraintdef(oid) INTO expected FROM pg_constraint
                    WHERE conrelid = 'pg_temp."__NullableCatalogSourceGuard"'::regclass AND conname = 'expected_Name';
                SELECT pg_get_constraintdef(oid) INTO definition FROM pg_constraint
                    WHERE conrelid = 'public."FileFormat"'::regclass AND conname = 'CK_FileFormat_Name_SourceLength' AND contype = 'c'
                    AND convalidated AND conislocal AND coninhcount = 0 AND NOT connoinherit
                    AND conkey = ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Name')]::smallint[];
                IF definition IS NULL OR definition IS DISTINCT FROM expected THEN
                    RAISE EXCEPTION 'Catalog downgrade constraint is incompatible.';
                END IF;
                IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Extension'
                    AND NOT attnotnull AND NOT atthasdef AND atttypid = 'text'::regtype AND NOT attisdropped) THEN
                    RAISE EXCEPTION 'Catalog downgrade schema is incompatible.';
                END IF;
                SELECT pg_get_constraintdef(oid) INTO expected FROM pg_constraint
                    WHERE conrelid = 'pg_temp."__NullableCatalogSourceGuard"'::regclass AND conname = 'expected_Extension';
                SELECT pg_get_constraintdef(oid) INTO definition FROM pg_constraint
                    WHERE conrelid = 'public."FileFormat"'::regclass AND conname = 'CK_FileFormat_Extension_SourceLength' AND contype = 'c'
                    AND convalidated AND conislocal AND coninhcount = 0 AND NOT connoinherit
                    AND conkey = ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid = 'public."FileFormat"'::regclass AND attname = 'Extension')]::smallint[];
                IF definition IS NULL OR definition IS DISTINCT FROM expected THEN
                    RAISE EXCEPTION 'Catalog downgrade constraint is incompatible.';
                END IF;
                DROP TABLE "__NullableCatalogSourceGuard";
            END $guard$;
            ALTER TABLE public."Category" DROP CONSTRAINT "CK_Category_Name_SourceLength";
            ALTER TABLE public."Category" ALTER COLUMN "Name" TYPE character varying(50);
            ALTER TABLE public."FileFormat" DROP CONSTRAINT "CK_FileFormat_Name_SourceLength";
            ALTER TABLE public."FileFormat" ALTER COLUMN "Name" TYPE character varying(50);
            ALTER TABLE public."FileFormat" DROP CONSTRAINT "CK_FileFormat_Extension_SourceLength";
            ALTER TABLE public."FileFormat" ALTER COLUMN "Extension" TYPE character varying(50);
            """);
    }
}
