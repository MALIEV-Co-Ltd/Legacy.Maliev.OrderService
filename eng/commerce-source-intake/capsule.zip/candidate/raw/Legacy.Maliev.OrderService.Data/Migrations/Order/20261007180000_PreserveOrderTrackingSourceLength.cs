using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Legacy.Maliev.OrderService.Data.Migrations.Order;

/// <inheritdoc />
public partial class PreserveOrderTrackingSourceLength : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            SET LOCAL lock_timeout = '5s';
            SET LOCAL statement_timeout = '30s';
            LOCK TABLE public."Order" IN ACCESS EXCLUSIVE MODE;
            DO $guard$
            BEGIN
                IF current_setting('server_encoding') <> 'UTF8'
                    OR NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."Order"'::regclass
                    AND attname = 'TrackingNumber' AND NOT attnotnull AND NOT atthasdef AND atttypid = 'varchar'::regtype AND atttypmod = 254 AND NOT attisdropped)
                    OR EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid = 'public."Order"'::regclass
                    AND conname = 'CK_Order_TrackingNumber_SourceLength') THEN
                    RAISE EXCEPTION 'Order tracking source schema is incompatible.';
                END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."Order" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Order tracking source preflight row limit exceeded.';
                END IF;
                IF EXISTS (SELECT 1 FROM public."Order" WHERE NOT (char_length("TrackingNumber") + char_length(regexp_replace("TrackingNumber" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 250)) THEN
                    RAISE EXCEPTION 'Order tracking retained rows violate source name constraints.';
                END IF;
            END $guard$;
            ALTER TABLE public."Order" ALTER COLUMN "TrackingNumber" TYPE text;
            ALTER TABLE public."Order" ADD CONSTRAINT "CK_Order_TrackingNumber_SourceLength" CHECK (char_length("TrackingNumber") + char_length(regexp_replace("TrackingNumber" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 250);
            """);
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.Sql("""
            SET LOCAL lock_timeout = '5s';
            SET LOCAL statement_timeout = '30s';
            LOCK TABLE public."Order" IN ACCESS EXCLUSIVE MODE;
            DO $guard$
            DECLARE definition text; expected text;
            BEGIN
                IF current_setting('server_encoding') <> 'UTF8'
                    OR NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid = 'public."Order"'::regclass
                    AND attname = 'TrackingNumber' AND NOT attnotnull AND NOT atthasdef AND atttypid = 'text'::regtype AND NOT attisdropped) THEN
                    RAISE EXCEPTION 'Order tracking downgrade schema is incompatible.';
                END IF;
                IF (SELECT count(*) FROM (SELECT 1 FROM public."Order" LIMIT 10001) bounded) > 10000 THEN
                    RAISE EXCEPTION 'Order tracking downgrade row limit exceeded.';
                END IF;
                CREATE TEMP TABLE "__OrderTrackingSourceGuard" (
                    "TrackingNumber" text,
                    CONSTRAINT "expected_TrackingNumber" CHECK (char_length("TrackingNumber") + char_length(regexp_replace("TrackingNumber" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 250)
                ) ON COMMIT DROP;
                SELECT pg_get_constraintdef(oid) INTO expected FROM pg_constraint
                    WHERE conrelid = 'pg_temp."__OrderTrackingSourceGuard"'::regclass AND conname = 'expected_TrackingNumber';
                SELECT pg_get_constraintdef(oid) INTO definition FROM pg_constraint
                    WHERE conrelid = 'public."Order"'::regclass
                    AND conname = 'CK_Order_TrackingNumber_SourceLength' AND contype = 'c'
                    AND convalidated AND conislocal AND coninhcount = 0 AND NOT connoinherit
                    AND conkey = ARRAY[(SELECT attnum FROM pg_attribute WHERE attrelid = 'public."Order"'::regclass AND attname = 'TrackingNumber')]::smallint[];
                IF definition IS NULL OR definition IS DISTINCT FROM expected THEN
                    RAISE EXCEPTION 'Order tracking downgrade constraint is incompatible.';
                END IF;
                DROP TABLE "__OrderTrackingSourceGuard";
            END $guard$;
            ALTER TABLE public."Order" DROP CONSTRAINT "CK_Order_TrackingNumber_SourceLength";
            ALTER TABLE public."Order" ALTER COLUMN "TrackingNumber" TYPE character varying(250);
            """);
    }
}
