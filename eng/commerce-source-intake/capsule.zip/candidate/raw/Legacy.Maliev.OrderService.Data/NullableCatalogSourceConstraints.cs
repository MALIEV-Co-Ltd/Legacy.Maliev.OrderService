using Legacy.Maliev.OrderService.Application.Models;

namespace Legacy.Maliev.OrderService.Data;

internal static class NullableCatalogSourceConstraints
{
    internal const string NameLengthSql = """
        char_length("Name") + char_length(regexp_replace("Name" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50
        """;
    internal const string ExtensionLengthSql = """
        char_length("Extension") + char_length(regexp_replace("Extension" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50
        """;

    internal static void Validate(UpsertCategoryRequest request)
    {
        if (request.Name?.Length > 50)
            throw new ArgumentException("The request is invalid.", nameof(request));
    }

    internal static void Validate(UpsertFileFormatRequest request)
    {
        if (request.Name?.Length > 50 || request.Extension?.Length > 50)
            throw new ArgumentException("The request is invalid.", nameof(request));
    }
}
