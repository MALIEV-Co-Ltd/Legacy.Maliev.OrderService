using Legacy.Maliev.OrderService.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Legacy.Maliev.OrderService.Data;

public sealed class OrderDbContext(DbContextOptions<OrderDbContext> options) : DbContext(options)
{
    public DbSet<OrderDeletionIntent> DeletionIntents => Set<OrderDeletionIntent>();
    public DbSet<Order> Orders => Set<Order>(); public DbSet<Process> Processes => Set<Process>(); public DbSet<Category> Categories => Set<Category>(); public DbSet<FileFormat> FileFormats => Set<FileFormat>(); public DbSet<OrderFile> Files => Set<OrderFile>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        var intent = b.Entity<OrderDeletionIntent>();
        intent.ToTable("OrderDeletionIntent", t => t.HasCheckConstraint("CK_OrderDeletionIntent_AttemptCount", "\"AttemptCount\" >= 0"));
        intent.HasKey(x => x.OrderId);
        intent.Property(x => x.OrderId).ValueGeneratedNever();
        intent.HasIndex(x => x.DeletionId).IsUnique();
        intent.HasIndex(x => new { x.NextAttemptAtUtc, x.OrderId }).HasDatabaseName("IX_OrderDeletionIntent_PendingDue").HasFilter("\"CompletedAtUtc\" IS NULL");
        intent.Property(x => x.RequestedAtUtc).HasColumnType("timestamp with time zone");
        intent.Property(x => x.StatusCleanupCompletedAtUtc).HasColumnType("timestamp with time zone");
        intent.Property(x => x.CompletedAtUtc).HasColumnType("timestamp with time zone");
        intent.Property(x => x.NextAttemptAtUtc).HasColumnType("timestamp with time zone");
        var c = b.Entity<Category>(); c.ToTable("Category", table => table.HasCheckConstraint("CK_Category_Name_SourceLength", NullableCatalogSourceConstraints.NameLengthSql)); c.HasKey(x => x.Id); c.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); c.Property(x => x.Name).HasMaxLength(50).HasColumnType("text"); Dates(c);
        var f = b.Entity<FileFormat>(); f.ToTable("FileFormat", table => { table.HasCheckConstraint("CK_FileFormat_Name_SourceLength", NullableCatalogSourceConstraints.NameLengthSql); table.HasCheckConstraint("CK_FileFormat_Extension_SourceLength", NullableCatalogSourceConstraints.ExtensionLengthSql); }); f.HasKey(x => x.Id); f.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); f.Property(x => x.Name).HasMaxLength(50).HasColumnType("text"); f.Property(x => x.Extension).HasMaxLength(50).HasColumnType("text"); Dates(f);
        var p = b.Entity<Process>(); p.ToTable("Process"); p.HasKey(x => x.Id); p.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); p.Property(x => x.CategoryId).HasColumnName("CategoryID"); p.Property(x => x.Name).HasMaxLength(50).IsRequired().HasColumnType("text"); p.ToTable("Process", table => table.HasCheckConstraint("CK_Process_Name_SourceLength", ProcessSourceConstraints.NameLengthSql)); Dates(p); p.HasOne(x => x.Category).WithMany(x => x.Processes).HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_Process_Category");
        var o = b.Entity<Order>(); o.ToTable("Order", table => { table.HasCheckConstraint("CK_Order_TrackingNumber_SourceLength", OrderTrackingSourceConstraints.LengthSql); table.HasCheckConstraint("CK_Order_Name_SourceLength", OrderTextSourceConstraints.NameLengthSql); table.HasCheckConstraint("CK_Order_Description_SourceLength", OrderTextSourceConstraints.DescriptionLengthSql); }); o.HasKey(x => x.Id); o.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); o.Property(x => x.CustomerId).HasColumnName("CustomerID"); o.Property(x => x.EmployeeId).HasColumnName("EmployeeID"); o.Property(x => x.ProcessId).HasColumnName("ProcessID"); o.Property(x => x.MaterialId).HasColumnName("MaterialID"); o.Property(x => x.SurfaceFinishId).HasColumnName("SurfaceFinishID"); o.Property(x => x.ColorId).HasColumnName("ColorID"); o.Property(x => x.CurrencyId).HasColumnName("CurrencyID"); o.Property(x => x.Name).HasMaxLength(100).HasColumnType("text").HasDefaultValue("unnamed"); o.Property(x => x.Description).HasMaxLength(250).HasColumnType("text"); o.Property(x => x.DiscountPercent).HasPrecision(5, 2); o.Property(x => x.UnitPrice).HasPrecision(18, 2); o.Property(x => x.TrackingNumber).HasMaxLength(250).HasColumnType("text"); o.Property(x => x.OperationKey).HasMaxLength(128); o.HasIndex(x => x.OperationKey).IsUnique(); o.Property(x => x.PromisedDate).HasColumnType("date"); o.Property(x => x.FinishedDate).HasColumnType("date"); o.Property(x => x.Remaining).HasComputedColumnSql("\"Quantity\" - \"Manufactured\"", true); o.Property(x => x.Subtotal).HasPrecision(18, 2).HasComputedColumnSql("(\"UnitPrice\" * \"Quantity\" - ((\"UnitPrice\" * \"Quantity\") * \"DiscountPercent\") / 100)::numeric(18,2)", true); o.Property(x => x.Turnaround).HasComputedColumnSql("(\"FinishedDate\" - \"CreatedDate\"::date)", true); Dates(o); o.Property(x => x.ModifiedDate).IsConcurrencyToken(); o.HasOne(x => x.Process).WithMany(x => x.Orders).HasForeignKey(x => x.ProcessId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_Order_Process");
        var of = b.Entity<OrderFile>(); of.ToTable("OrderFile", table => table.HasCheckConstraint("CK_OrderFile_Bucket_SourceLength", OrderFileBucketSourceConstraints.LengthSql)); of.HasKey(x => x.Id); of.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); of.Property(x => x.OrderId).HasColumnName("OrderID"); of.Property(x => x.Bucket).HasMaxLength(50).HasColumnType("text").IsRequired(); of.Property(x => x.ObjectName).IsRequired(); Dates(of); of.HasOne(x => x.Order).WithMany(x => x.Files).HasForeignKey(x => x.OrderId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_OrderFile_Order");
    }
    private static void Dates<T>(EntityTypeBuilder<T> e) where T : class { e.Property<DateTime?>("CreatedDate").HasColumnType("timestamp without time zone").HasDefaultValueSql("CURRENT_TIMESTAMP AT TIME ZONE 'UTC'"); e.Property<DateTime?>("ModifiedDate").HasColumnType("timestamp without time zone").HasDefaultValueSql("CURRENT_TIMESTAMP AT TIME ZONE 'UTC'"); }
}

public sealed class OrderStatusDbContext(DbContextOptions<OrderStatusDbContext> options) : DbContext(options)
{
    public DbSet<OrderStatus> Statuses => Set<OrderStatus>(); public DbSet<OrderStatusTransition> Transitions => Set<OrderStatusTransition>(); public DbSet<OrderStatusHistory> History => Set<OrderStatusHistory>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        var s = b.Entity<OrderStatus>(); s.ToTable("OrderStatus"); s.HasKey(x => x.Id); s.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); s.Property(x => x.Name).IsRequired().HasMaxLength(50).HasColumnType("text"); s.Property(x => x.Description).HasMaxLength(100).HasColumnType("text");
        s.ToTable("OrderStatus", table =>
        {
            table.HasCheckConstraint("CK_OrderStatus_Name_SourceLength", OrderStatusSourceConstraints.NameLengthSql);
            table.HasCheckConstraint("CK_OrderStatus_Description_SourceLength", OrderStatusSourceConstraints.DescriptionLengthSql);
        });
        Dates(s);
        var t = b.Entity<OrderStatusTransition>(); t.ToTable("OrderStatusHasPossibleStatus"); t.HasKey(x => x.Id); t.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); t.Property(x => x.OrderStatusId).HasColumnName("OrderStatusID"); t.Property(x => x.PossibleStatusId).HasColumnName("PossibleStatusID"); Dates(t); t.HasOne(x => x.OrderStatus).WithMany(x => x.FromTransitions).HasForeignKey(x => x.OrderStatusId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_OrderStatusHasPossibleStatus_OrderStatus"); t.HasOne(x => x.PossibleStatus).WithMany(x => x.ToTransitions).HasForeignKey(x => x.PossibleStatusId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_OrderStatusHasPossibleStatus_OrderStatus1");
        var h = b.Entity<OrderStatusHistory>(); h.ToTable("OrderStatusHistory"); h.HasKey(x => x.Id); h.Property(x => x.Id).HasColumnName("ID").ValueGeneratedOnAdd(); h.Property(x => x.OrderId).HasColumnName("OrderID"); h.Property(x => x.OrderStatusId).HasColumnName("OrderStatusID"); Dates(h); h.Property(x => x.ModifiedDate).IsConcurrencyToken(); h.HasOne(x => x.OrderStatus).WithMany(x => x.History).HasForeignKey(x => x.OrderStatusId).OnDelete(DeleteBehavior.NoAction).HasConstraintName("FK_OrderHasOrderStatus_OrderStatus");
    }
    private static void Dates<T>(EntityTypeBuilder<T> e) where T : class { e.Property<DateTime?>("CreatedDate").HasColumnType("timestamp without time zone").HasDefaultValueSql("CURRENT_TIMESTAMP AT TIME ZONE 'UTC'"); e.Property<DateTime?>("ModifiedDate").HasColumnType("timestamp without time zone").HasDefaultValueSql("CURRENT_TIMESTAMP AT TIME ZONE 'UTC'"); }
}
