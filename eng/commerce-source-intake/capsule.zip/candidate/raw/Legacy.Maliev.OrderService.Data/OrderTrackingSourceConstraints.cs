using Legacy.Maliev.OrderService.Application.Models;

namespace Legacy.Maliev.OrderService.Data;

internal static class OrderTrackingSourceConstraints
{
    internal const string LengthSql = """
        char_length("TrackingNumber") + char_length(regexp_replace("TrackingNumber" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 250
        """;

    internal static void Validate(UpsertOrderRequest request)
    {
        if (request.TrackingNumber?.Length > 250)
            throw new ArgumentException("The request is invalid.", nameof(request));
    }
}
