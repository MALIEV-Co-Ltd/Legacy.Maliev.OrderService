namespace Legacy.Maliev.OrderService.Data;

internal static class OrderFileBucketSourceConstraints
{
    internal const string LengthSql = """
        char_length("Bucket") + char_length(regexp_replace("Bucket" COLLATE "C", U&'[\0001-\FFFF]', '', 'g')) <= 50
        """;

    internal static string Normalize(string bucket)
    {
        if (string.IsNullOrWhiteSpace(bucket))
            throw new ArgumentException("The request is invalid.", nameof(bucket));
        var normalized = bucket.Trim();
        if (normalized.Length > 50)
            throw new ArgumentException("The request is invalid.", nameof(bucket));
        return normalized;
    }
}
