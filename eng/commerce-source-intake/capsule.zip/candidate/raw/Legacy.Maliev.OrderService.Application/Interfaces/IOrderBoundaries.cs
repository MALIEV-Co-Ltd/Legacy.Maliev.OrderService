using Legacy.Maliev.OrderService.Application.Models;
namespace Legacy.Maliev.OrderService.Application.Interfaces;

public interface IOrderService
{
    Task<OrderResponse> CreateOrderAsync(UpsertOrderRequest r, CancellationToken c); Task<bool> DeleteOrderAsync(int id, CancellationToken c); Task<OrderResponse?> GetOrderAsync(int id, CancellationToken c); Task<PaginatedResponse<OrderResponse>?> GetOrdersAsync(int? customerId, bool pending, OrderSortType? sort, string? search, int page, int? size, CancellationToken c); Task<UpdateResult> UpdateOrderAsync(int id, UpsertOrderRequest r, DateTimeOffset? expected, CancellationToken c);
    Task<CustomerOrderDetails?> GetCustomerOrderAsync(int customerId, int orderId, CancellationToken c); Task<UpdateResult> CancelCustomerOrderAsync(int customerId, int orderId, CancellationToken c);
    Task<CategoryResponse> CreateCategoryAsync(UpsertCategoryRequest r, CancellationToken c); Task<bool> DeleteCategoryAsync(int id, CancellationToken c); Task<CategoryResponse?> GetCategoryAsync(int id, CancellationToken c); Task<bool> UpdateCategoryAsync(int id, UpsertCategoryRequest r, CancellationToken c);
    Task<FileFormatResponse> CreateFileFormatAsync(UpsertFileFormatRequest r, CancellationToken c); Task<bool> DeleteFileFormatAsync(int id, CancellationToken c); Task<IReadOnlyList<FileFormatResponse>> GetFileFormatsAsync(CancellationToken c); Task<FileFormatResponse?> GetFileFormatAsync(int id, CancellationToken c); Task<bool> UpdateFileFormatAsync(int id, UpsertFileFormatRequest r, CancellationToken c);
    Task<ProcessResponse> CreateProcessAsync(UpsertProcessRequest r, CancellationToken c); Task<bool> DeleteProcessAsync(int id, CancellationToken c); Task<IReadOnlyList<ProcessResponse>> GetProcessesAsync(string? category, CancellationToken c); Task<ProcessResponse?> GetProcessAsync(int id, CancellationToken c); Task<bool> UpdateProcessAsync(int id, UpsertProcessRequest r, CancellationToken c);
    Task<OrderFileResponse?> CreateFileAsync(int orderId, string bucket, string objectName, CancellationToken c); Task<bool> DeleteFileAsync(int id, CancellationToken c); Task<OrderFileResponse?> GetFileAsync(int id, CancellationToken c); Task<IReadOnlyList<OrderFileResponse>> GetFilesAsync(int orderId, CancellationToken c); Task<bool> UpdateFileAsync(int id, UpsertOrderFileRequest r, CancellationToken c);
    Task<OrderStatusResponse> CreateStatusAsync(UpsertOrderStatusRequest r, CancellationToken c); Task<bool> DeleteStatusAsync(int id, CancellationToken c); Task<IReadOnlyList<OrderStatusResponse>> GetStatusesAsync(CancellationToken c); Task<OrderStatusResponse?> GetStatusAsync(int id, CancellationToken c); Task<OrderStatusResponse?> GetStatusAsync(string name, CancellationToken c); Task<bool> UpdateStatusAsync(int id, UpsertOrderStatusRequest r, CancellationToken c); Task<IReadOnlyList<OrderStatusResponse>> GetAvailableStatusesAsync(int currentStatusId, CancellationToken c);
    Task<UpdateResult> TransitionAsync(int orderId, int statusId, CancellationToken c); Task<UpdateResult> TransitionAsync(int orderId, string statusName, CancellationToken c); Task<bool> DeleteHistoryAsync(int id, CancellationToken c); Task<OrderStatusResponse?> GetLatestStatusAsync(int orderId, CancellationToken c); Task<IReadOnlyList<OrderStatusHistoryResponse>> GetHistoryAsync(int orderId, CancellationToken c); Task<UpdateResult> UpdateHistoryAsync(int id, UpsertOrderStatusHistoryRequest r, DateTimeOffset? expected, CancellationToken c);
}
public interface IOrderCache { Task<T?> GetAsync<T>(string k, CancellationToken c) where T : class; Task SetAsync<T>(string k, T v, TimeSpan t, CancellationToken c) where T : class; Task RemoveAsync(string k, CancellationToken c); }
public interface IIdempotencyStore
{
    Task<IdempotencyAcquireResult<T>> AcquireAsync<T>(string scope, string key, string requestFingerprint, CancellationToken cancellationToken) where T : class;
    Task CompleteAsync<T>(string scope, string key, string requestFingerprint, string reservationId, T response, CancellationToken cancellationToken) where T : class;
    Task ReleaseAsync(string scope, string key, string reservationId, CancellationToken cancellationToken);
}
public enum IdempotencyAcquireState { Acquired, Replay, Conflict, InProgress }
public sealed record IdempotencyAcquireResult<T>(IdempotencyAcquireState State, string? ReservationId, T? Response) where T : class;
public sealed class IdempotencyStoreUnavailableException(string message, Exception? innerException = null) : Exception(message, innerException);
