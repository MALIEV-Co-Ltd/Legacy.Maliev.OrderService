using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using DotNet.Testcontainers.Builders;
using DotNet.Testcontainers.Containers;
using Legacy.Maliev.OrderService.Application.Interfaces;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using StackExchange.Redis;
using Xunit.Abstractions;

namespace Legacy.Maliev.OrderService.Tests.Caching;

public sealed class RedisIdempotencyIntegrationTests(ITestOutputHelper output) : IAsyncLifetime
{
    private readonly IContainer redisContainer = CreateContainer();
    private IConnectionMultiplexer? connection;

    private static IContainer CreateContainer() => new ContainerBuilder("redis:8.0-alpine")
        .WithDockerEndpoint(OwnedOrderTestContainers.DockerEndpoint)
        .WithPortBinding(6379, true)
        .WithLabel("maliev.codex.owner", "commerce-order-redis331-compat-20261007")
        .WithLabel("maliev.codex.parent-run", OwnedOrderTestContainers.ParentRun)
        .WithLabel("maliev.codex.run", Guid.NewGuid().ToString("N"))
        .WithLabel("maliev.codex.purpose", "disposable-redis-idempotency-regression")
        .WithLabel("maliev.codex.expires-utc", DateTime.UtcNow.AddMinutes(11).ToString("O"))
        .WithLabel("maliev.codex.persistent-data", "false")
        .WithCommand("sh", "-c", "exec timeout 600 redis-server --save '' --appendonly no")
        .WithCreateParameterModifier(parameters =>
        {
            parameters.HostConfig!.Memory = 256 * 1024 * 1024;
            parameters.HostConfig.MemorySwap = 256 * 1024 * 1024;
            parameters.HostConfig.NanoCPUs = 500000000;
            parameters.HostConfig.Tmpfs = new Dictionary<string, string> { ["/data"] = "rw,size=64m" };
            foreach (var bindings in parameters.HostConfig.PortBindings.Values)
            {
                foreach (var binding in bindings) binding.HostIP = "127.0.0.1";
            }
        })
        .WithWaitStrategy(Wait.ForUnixContainer().UntilInternalTcpPortIsAvailable(6379))
        .Build();

    public async Task InitializeAsync()
    {
        try
        {
            using var startup = new CancellationTokenSource(TimeSpan.FromSeconds(60));
            await redisContainer.StartAsync(startup.Token);
            output.WriteLine($"Owned disposable Redis container: {redisContainer.Id}; loopback port: {redisContainer.GetMappedPublicPort(6379)}; lease: 600 seconds; memory: 256 MiB; CPU: 0.5; /data: tmpfs.");
            var configuration = ConfigurationOptions.Parse(
                $"{redisContainer.Hostname}:{redisContainer.GetMappedPublicPort(6379)}");
            configuration.AbortOnConnectFail = true;
            configuration.ConnectRetry = 0;
            configuration.ConnectTimeout = 10000;
            configuration.AsyncTimeout = 10000;
            configuration.SyncTimeout = 10000;
            var connecting = ConnectionMultiplexer.ConnectAsync(configuration);
            try
            {
                connection = await connecting.WaitAsync(TimeSpan.FromSeconds(30));
            }
            catch
            {
                _ = connecting.ContinueWith(task => task.Result.Dispose(), CancellationToken.None,
                    TaskContinuationOptions.OnlyOnRanToCompletion | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
                throw;
            }
        }
        catch
        {
            await DisposeAsync();
            throw;
        }
    }

    public async Task DisposeAsync()
    {
        try
        {
            if (connection is not null)
            {
                try
                {
                    await connection.CloseAsync().WaitAsync(TimeSpan.FromSeconds(10));
                }
                finally
                {
                    connection.Dispose();
                    connection = null;
                }
            }
        }
        finally
        {
            await OwnedOrderTestContainers.WaitForCleanupAsync(redisContainer.DisposeAsync().AsTask());
            output.WriteLine("Owned disposable Redis container disposal completed.");
        }
    }

    [Fact]
    public async Task RedisReservation_AllowsOneWriterThenReplaysCompletedResponse()
    {
        var firstStore = Store();
        var secondStore = Store();

        var acquisitions = await Task.WhenAll(
            firstStore.AcquireAsync<OrderStatusResponse>("order:employee-a", "shared-key", "fingerprint", default),
            secondStore.AcquireAsync<OrderStatusResponse>("order:employee-a", "shared-key", "fingerprint", default));

        var acquired = Assert.Single(acquisitions, value => value.State == IdempotencyAcquireState.Acquired);
        Assert.Single(acquisitions, value => value.State == IdempotencyAcquireState.InProgress);
        var response = new OrderStatusResponse(7, "Accepted", null, null, null);
        await firstStore.CompleteAsync(
            "order:employee-a",
            "shared-key",
            "fingerprint",
            Assert.IsType<string>(acquired.ReservationId),
            response,
            default);

        var completedTtl = await connection!.GetDatabase().KeyTimeToLiveAsync(
            StorageKey("order:employee-a", "shared-key"));
        Assert.InRange(Assert.IsType<TimeSpan>(completedTtl), TimeSpan.FromHours(24) - TimeSpan.FromMinutes(1), TimeSpan.FromHours(24));

        var replay = await secondStore.AcquireAsync<OrderStatusResponse>(
            "order:employee-a",
            "shared-key",
            "fingerprint",
            default);
        var mismatch = await secondStore.AcquireAsync<OrderStatusResponse>(
            "order:employee-a",
            "shared-key",
            "different-fingerprint",
            default);

        Assert.Equal(IdempotencyAcquireState.Replay, replay.State);
        Assert.Equal(response, replay.Response);
        Assert.Equal(IdempotencyAcquireState.Conflict, mismatch.State);
    }

    [Theory]
    [InlineData(true, false)]
    [InlineData(true, true)]
    [InlineData(false, false)]
    [InlineData(false, true)]
    public async Task RedisReservation_ConcurrentReplacementOrRemovalCannotBeOverwrittenOrDeleted(bool complete, bool remove)
    {
        const string scope = "order:race";
        const string key = "race-key";
        var store = Store();
        var acquired = await store.AcquireAsync<OrderStatusResponse>(scope, key, "fingerprint", default);
        var reservation = Assert.IsType<string>(acquired.ReservationId);
        var database = connection!.GetDatabase();
        var storageKey = StorageKey(scope, key);
        var replacement = Encoding.UTF8.GetBytes("competing-writer-value");
        var intercepted = false;
        var databaseProxy = DispatchProxy.Create<IDatabase, RedisCallProxy>();
        ((RedisCallProxy)databaseProxy).InvokeCall = (method, arguments) =>
        {
            if (method.Name == nameof(IDatabase.ScriptEvaluateAsync))
            {
                return MutateThenEvaluateAsync(method, arguments);
            }

            return method.Invoke(database, arguments);
        };
        var connectionProxy = DispatchProxy.Create<IConnectionMultiplexer, RedisCallProxy>();
        ((RedisCallProxy)connectionProxy).InvokeCall = (method, arguments) =>
            method.Name == nameof(IConnectionMultiplexer.GetDatabase)
                ? databaseProxy : method.Invoke(connection, arguments);
        var racingStore = Store(connectionProxy);
        if (complete)
        {
            await Assert.ThrowsAsync<IdempotencyStoreUnavailableException>(() => racingStore.CompleteAsync(
                scope, key, "fingerprint", reservation, new OrderStatusResponse(7, "Accepted", null, null, null), default));
        }
        else
        {
            await racingStore.ReleaseAsync(scope, key, reservation, default);
        }

        Assert.True(intercepted);
        var after = await database.StringGetAsync(storageKey);
        if (remove) Assert.False(after.HasValue);
        else Assert.Equal(replacement, (byte[])after!);

        async Task<RedisResult> MutateThenEvaluateAsync(MethodInfo method, object?[]? arguments)
        {
            Assert.False(intercepted);
            intercepted = true;
            if (remove) await database.KeyDeleteAsync(storageKey);
            else await database.StringSetAsync(storageKey, replacement, TimeSpan.FromMinutes(5));
            return await Assert.IsAssignableFrom<Task<RedisResult>>(method.Invoke(database, arguments));
        }
    }

    [Fact]
    public async Task RedisReservation_WrongOwnerAndCancellationPreservePendingValueThenOwnerCanRelease()
    {
        const string scope = "order:owner";
        const string key = "owner-key";
        var store = Store();
        var acquired = await store.AcquireAsync<OrderStatusResponse>(scope, key, "fingerprint", default);
        var database = connection!.GetDatabase();
        var before = await database.StringGetAsync(StorageKey(scope, key));
        await store.ReleaseAsync(scope, key, "wrong-owner", default);
        await Assert.ThrowsAsync<IdempotencyStoreUnavailableException>(() => store.CompleteAsync(
            scope, key, "fingerprint", "wrong-owner", new OrderStatusResponse(7, "Accepted", null, null, null), default));
        using var cancellation = new CancellationTokenSource();
        await cancellation.CancelAsync();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => store.CompleteAsync(
            scope, key, "fingerprint", Assert.IsType<string>(acquired.ReservationId),
            new OrderStatusResponse(7, "Accepted", null, null, null), cancellation.Token));
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => store.ReleaseAsync(
            scope, key, Assert.IsType<string>(acquired.ReservationId), cancellation.Token));
        Assert.Equal(before, await database.StringGetAsync(StorageKey(scope, key)));
        await store.ReleaseAsync(scope, key, Assert.IsType<string>(acquired.ReservationId), default);
        Assert.False((await database.StringGetAsync(StorageKey(scope, key))).HasValue);
        await store.ReleaseAsync(scope, key, "missing-owner", default);
        await Assert.ThrowsAsync<IdempotencyStoreUnavailableException>(() => store.CompleteAsync(
            scope, key, "fingerprint", Assert.IsType<string>(acquired.ReservationId),
            new OrderStatusResponse(7, "Accepted", null, null, null), default));
    }

    private static string StorageKey(string scope, string key) =>
        $"legacy:order:idempotency:v3:{Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{scope}\n{key}")))}";

    public class RedisCallProxy : DispatchProxy
    {
        public Func<MethodInfo, object?[]?, object?> InvokeCall { get; set; } = null!;

        protected override object? Invoke(MethodInfo? targetMethod, object?[]? args) =>
            InvokeCall(targetMethod ?? throw new InvalidOperationException("Missing Redis method."), args);
    }

    private IIdempotencyStore Store(IConnectionMultiplexer? overrideConnection = null) => new DistributedOrderCache(
        new MemoryDistributedCache(Options.Create(new MemoryDistributedCacheOptions())),
        NullLogger<DistributedOrderCache>.Instance,
        overrideConnection ?? connection ?? throw new InvalidOperationException("Redis connection is not initialized."));
}
