using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Time.Testing;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderFullScalarSourceHttpTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(3)]
    public async Task FullSourceScalarsRoundTripThroughCreateUpdateFreshGetAndDatabase(int mode)
    {
        var clock = new FakeTimeProvider(new DateTimeOffset(2026, 10, 7, 1, 0, 0, TimeSpan.Zero));
        await using var app = await fixture.AppAsync(null, configure: services =>
        {
            services.RemoveAll<TimeProvider>();
            services.AddSingleton<TimeProvider>(clock);
        });
        using var setup = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        int firstProcess;
        int secondProcess;
        int sentinelId;
        await using (var scope = app.Services.CreateAsyncScope())
        {
            var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
            var first = new Process { Name = "First source process", Category = new Category { Name = "First source category" } };
            var second = new Process { Name = "Second source process", Category = new Category { Name = "Second source category" } };
            var sentinel = new Order { Name = "Unchanged sentinel", Quantity = 3, Manufactured = 1, UnitPrice = 7.89m, DiscountPercent = 0m,
                Process = new Process { Name = "Sentinel process", Category = new Category { Name = "Sentinel category" } } };
            database.AddRange(first, second, sentinel);
            await database.SaveChangesAsync(setup.Token);
            firstProcess = first.Id;
            secondProcess = second.Id;
            sentinelId = sentinel.Id;
        }

        using var reader = Client(app, "legacy.orders.read");
        using var creator = Client(app, "legacy.orders.create");
        using var updater = Client(app, "legacy.orders.update");
        var sentinelBefore = await ReadAsync(reader, sentinelId);
        var catalogBefore = await CatalogSnapshotAsync(app);
        var create = Payload(mode, false, firstProcess);
        Assert.Equal(21, create.Count);
        foreach (var excluded in new[] { "Remaining", "Subtotal", "Turnaround", "CreatedDate", "ModifiedDate", "OperationKey" })
            Assert.False(create.ContainsKey(excluded));
        using var request = new HttpRequestMessage(HttpMethod.Post, "/orders") { Content = JsonContent.Create(create) };
        request.Headers.Add("Idempotency-Key", Guid.NewGuid().ToString("N"));
        var expectedCreated = clock.GetUtcNow().UtcDateTime;
        using var created = await creator.SendAsync(request);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        Assert.NotNull(created.Headers.Location);
        using var createdDocument = JsonDocument.Parse(await created.Content.ReadAsStringAsync());
        var current = createdDocument.RootElement.Clone();
        var id = current.GetProperty("Id").GetInt32();
        using var locationResponse = await reader.GetAsync(created.Headers.Location);
        Assert.Equal(HttpStatusCode.OK, locationResponse.StatusCode);
        Assert.Equal(current.GetRawText(), await locationResponse.Content.ReadAsStringAsync());
        await AssertReadbackAsync(app, reader, id, create, current, clock.GetUtcNow().UtcDateTime, expectedCreated, created: true);

        if (mode == 1)
        {
            clock.Advance(TimeSpan.FromSeconds(2));
            current = await UpdateAsync(updater, reader, id, Payload(0, true, secondProcess), current);
            await AssertReadbackAsync(app, reader, id, Payload(0, true, secondProcess), current, clock.GetUtcNow().UtcDateTime, expectedCreated, created: false);
        }
        clock.Advance(TimeSpan.FromSeconds(2));
        var update = Payload(mode, true, secondProcess);
        var originalCreated = current.GetProperty("CreatedDate").GetDateTime();
        current = await UpdateAsync(updater, reader, id, update, current);
        Assert.Equal(originalCreated, current.GetProperty("CreatedDate").GetDateTime());
        await AssertReadbackAsync(app, reader, id, update, current, clock.GetUtcNow().UtcDateTime, expectedCreated, created: false);
        Assert.Equal(sentinelBefore.GetRawText(), (await ReadAsync(reader, sentinelId)).GetRawText());
        Assert.Equal(catalogBefore, await CatalogSnapshotAsync(app));
        await using var finalScope = app.Services.CreateAsyncScope();
        var finalOrders = finalScope.ServiceProvider.GetRequiredService<OrderDbContext>();
        Assert.Equal(2, await finalOrders.Orders.CountAsync(setup.Token));
        Assert.Equal(3, await finalOrders.Processes.CountAsync(setup.Token));
        Assert.Equal(3, await finalOrders.Categories.CountAsync(setup.Token));
        Assert.Empty(await finalOrders.Files.AsNoTracking().ToArrayAsync(setup.Token));
        var finalStatuses = finalScope.ServiceProvider.GetRequiredService<OrderStatusDbContext>();
        Assert.Empty(await finalStatuses.Statuses.AsNoTracking().ToArrayAsync(setup.Token));
        Assert.Empty(await finalStatuses.History.AsNoTracking().ToArrayAsync(setup.Token));
        Assert.Empty(await finalStatuses.Transitions.AsNoTracking().ToArrayAsync(setup.Token));
    }

    private HttpClient Client(WebApplicationFactory<Program> app, string permission)
    {
        var client = app.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(30);
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.Token(permission));
        return client;
    }

    private static Dictionary<string, object?> Payload(int mode, bool update, int process)
    {
        object? Reference(int offset) => mode == 1 ? null : (update ? 1900 : 900) + offset;
        string? Literal(string field) => mode switch
        {
            1 => null,
            2 => string.Empty,
            3 => $" {field}-{(update ? "update" : "create")} ",
            _ => $"{field}-{(update ? "update" : "create")}",
        };
        return new()
        {
            ["CustomerId"] = Reference(1), ["EmployeeId"] = Reference(2),
            ["Name"] = Literal("Name"), ["Description"] = Literal("Description"),
            ["ProcessId"] = process, ["MaterialId"] = Reference(3), ["SurfaceFinishId"] = Reference(4), ["ColorId"] = Reference(5),
            ["Quantity"] = update ? 17 : 11, ["Manufactured"] = update ? 5 : 3,
            ["UnitPrice"] = mode == 1 ? null : update ? 9.87m : 12.34m,
            ["DiscountPercent"] = mode == 1 ? null : update ? 25m : 12.5m,
            ["CurrencyId"] = Reference(6), ["LeadTime"] = mode == 1 ? null : update ? 9 : 7,
            ["PromisedDate"] = mode == 1 ? null : new DateTime(2026, 11, update ? 13 : 12),
            ["FinishedDate"] = mode == 1 ? null : new DateTime(2026, 10, update ? 10 : 9),
            ["Comment"] = Literal("Comment"), ["AllowSocialMedia"] = mode is 0 or 2 ? !update : update,
            ["AllowCancellation"] = mode is 0 or 1 ? update : !update,
            ["AllowPayment"] = mode is 1 or 2 ? !update : update, ["TrackingNumber"] = Literal("TrackingNumber"),
        };
    }

    private static async Task<JsonElement> UpdateAsync(HttpClient updater, HttpClient reader, int id, Dictionary<string, object?> payload, JsonElement before)
    {
        using var request = new HttpRequestMessage(HttpMethod.Put, $"/orders/{id}") { Content = JsonContent.Create(payload) };
        request.Headers.Add("X-Expected-Modified-Date", DateTime.SpecifyKind(before.GetProperty("ModifiedDate").GetDateTime(), DateTimeKind.Utc).ToString("O"));
        using var response = await updater.SendAsync(request);
        Assert.Equal(HttpStatusCode.NoContent, response.StatusCode);
        return await ReadAsync(reader, id);
    }

    private static async Task<JsonElement> ReadAsync(HttpClient reader, int id)
    {
        using var response = await reader.GetAsync($"/orders/{id}");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var document = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        return document.RootElement.Clone();
    }

    private static async Task<string> CatalogSnapshotAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var processes = await database.Processes.AsNoTracking().OrderBy(value => value.Id)
            .Select(value => new { value.Id, value.CategoryId, value.Name, value.CreatedDate, value.ModifiedDate }).ToArrayAsync(lifetime.Token);
        var categories = await database.Categories.AsNoTracking().OrderBy(value => value.Id)
            .Select(value => new { value.Id, value.Name, value.CreatedDate, value.ModifiedDate }).ToArrayAsync(lifetime.Token);
        return JsonSerializer.Serialize(new { processes, categories });
    }

    private static async Task AssertReadbackAsync(WebApplicationFactory<Program> app, HttpClient reader, int id,
        Dictionary<string, object?> payload, JsonElement expectedWire, DateTime modified, DateTime expectedCreated, bool created)
    {
        var wire = await ReadAsync(reader, id);
        Assert.Equal(expectedWire.GetRawText(), wire.GetRawText());
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var row = await database.Orders.AsNoTracking().SingleAsync(value => value.Id == id, lifetime.Token);
        foreach (var (field, supplied) in payload)
        {
            var expected = field == "Name" && supplied is null && created ? "unnamed" : supplied;
            Assert.Equal(expected, database.Entry(row).Property(field).CurrentValue);
            Assert.False(wire.TryGetProperty(char.ToLowerInvariant(field[0]) + field[1..], out _));
            if (expected is null) Assert.False(wire.TryGetProperty(field, out _));
            else if (expected is DateTime date) Assert.Equal(date, wire.GetProperty(field).GetDateTime());
            else if (expected is decimal money) Assert.Equal(money, wire.GetProperty(field).GetDecimal());
            else if (expected is int number) Assert.Equal(number, wire.GetProperty(field).GetInt32());
            else if (expected is bool flag) Assert.Equal(flag, wire.GetProperty(field).GetBoolean());
            else Assert.Equal(Assert.IsType<string>(expected), wire.GetProperty(field).GetString());
        }
        var remaining = (int)payload["Quantity"]! - (int)payload["Manufactured"]!;
        decimal? subtotal = payload["UnitPrice"] is decimal price && payload["DiscountPercent"] is decimal discount
            ? decimal.Round(price * (int)payload["Quantity"]! * (1m - discount / 100m), 2, MidpointRounding.AwayFromZero) : null;
        int? turnaround = payload["FinishedDate"] is DateTime finish ? (finish.Date - expectedCreated.Date).Days : null;
        Assert.Equal(remaining, row.Remaining);
        Assert.Equal(subtotal, row.Subtotal);
        Assert.Equal(turnaround, row.Turnaround);
        Assert.Equal(remaining, wire.GetProperty("Remaining").GetInt32());
        if (subtotal is null) Assert.False(wire.TryGetProperty("Subtotal", out _));
        else Assert.Equal(subtotal, wire.GetProperty("Subtotal").GetDecimal());
        if (turnaround is null) Assert.False(wire.TryGetProperty("Turnaround", out _));
        else Assert.Equal(turnaround, wire.GetProperty("Turnaround").GetInt32());
        Assert.Equal(modified, row.ModifiedDate);
        Assert.Equal(modified, wire.GetProperty("ModifiedDate").GetDateTime());
        Assert.Equal(expectedCreated, row.CreatedDate);
        Assert.Equal(expectedCreated, wire.GetProperty("CreatedDate").GetDateTime());
        Assert.Null(row.OperationKey);
    }
}
