using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.OrderService.Api.Authorization;
using Legacy.Maliev.OrderService.Application.Interfaces;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class NullableCatalogSourceHttpTests(OrderDeletionReadinessFixture fixture) : IClassFixture<OrderDeletionReadinessFixture>
{
    public static TheoryData<string, bool, bool> Boundaries => new()
    {
        { "Category.Name", false, false },
        { "Category.Name", false, true },
        { "Category.Name", true, false },
        { "Category.Name", true, true },
        { "FileFormat.Name", false, false },
        { "FileFormat.Name", false, true },
        { "FileFormat.Name", true, false },
        { "FileFormat.Name", true, true },
        { "FileFormat.Extension", false, false },
        { "FileFormat.Extension", false, true },
        { "FileFormat.Extension", true, false },
        { "FileFormat.Extension", true, true },
    };
    [Theory]
    [MemberData(nameof(Boundaries))]
    public async Task Utf16BoundaryReadbackAndOverflowNoWrite(string field, bool put, bool supplementary)
    {
        await using var app = await fixture.AppAsync(null);
        using var writer = Client(app, OrderPermissions.CatalogWrite);
        using var reader = Client(app, OrderPermissions.CatalogRead);
        var id = await SeedAsync(writer, field);
        var exact = supplementary ? string.Concat(Enumerable.Repeat("😀", 24)) + "  " : new string('ก', 48) + "  ";
        Assert.Equal(50, exact.Length);
        using var valid = await SendAsync(writer, field, put, id, exact);
        Assert.Equal(put ? HttpStatusCode.NoContent : HttpStatusCode.Created, valid.StatusCode);
        if (!put) id = (await ValueAsync(valid, field)).Id;
        var readback = await ReadAsync(reader, field, id);
        Assert.Equal(exact, FieldValue(readback, field));
        if (field == "FileFormat.Name") Assert.Equal(".sibling", readback.Extension);
        if (field == "FileFormat.Extension") Assert.Equal("Synthetic sibling", readback.Name);
        await AssertPhysicalAsync(app, field, id, exact);
        var before = await GraphAsync(app);
        using var invalid = await SendAsync(writer, field, put, id, exact + "ก");
        Assert.Equal(HttpStatusCode.BadRequest, invalid.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
        Assert.Equal(readback, await ReadAsync(reader, field, id));
    }
    public static TheoryData<string, string?> Literals => new()
    {
        { "Category.Name", null },
        { "Category.Name", "" },
        { "Category.Name", "  " },
        { "Category.Name", " ก padded " },
        { "FileFormat.Name", null },
        { "FileFormat.Name", "" },
        { "FileFormat.Name", "  " },
        { "FileFormat.Name", " ก padded " },
        { "FileFormat.Extension", null },
        { "FileFormat.Extension", "" },
        { "FileFormat.Extension", "  " },
        { "FileFormat.Extension", " ก padded " },
    };
    [Theory]
    [MemberData(nameof(Literals))]
    public async Task NullEmptyPaddingCreateAndClearUpdate(string field, string? literal)
    {
        await using var app = await fixture.AppAsync(null);
        using var writer = Client(app, OrderPermissions.CatalogWrite);
        using var reader = Client(app, OrderPermissions.CatalogRead);
        var id = await SeedAsync(writer, field);
        using var create = await SendAsync(writer, field, false, 0, literal);
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        Assert.NotNull(create.Headers.Location);
        var created = await ValueAsync(create, field);
        Assert.Equal(created, await ReadAsync(reader, field, created.Id));
        Assert.Equal(literal, FieldValue(created, field));
        await AssertPhysicalAsync(app, field, created.Id, literal);
        using var update = await SendAsync(writer, field, true, id, literal);
        Assert.Equal(HttpStatusCode.NoContent, update.StatusCode);
        Assert.Equal(literal, FieldValue(await ReadAsync(reader, field, id), field));
        await AssertPhysicalAsync(app, field, id, literal);
    }
    [Theory]
    [InlineData("Category.Name", false)]
    [InlineData("Category.Name", true)]
    [InlineData("FileFormat.Name", false)]
    [InlineData("FileFormat.Name", true)]
    [InlineData("FileFormat.Extension", false)]
    [InlineData("FileFormat.Extension", true)]
    public async Task DirectServiceOverflowRefusesBeforeTrackedMutation(string field, bool put)
    {
        await using var app = await fixture.AppAsync(null);
        using var writer = Client(app, OrderPermissions.CatalogWrite);
        var id = await SeedAsync(writer, field);
        var before = await GraphAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var service = scope.ServiceProvider.GetRequiredService<IOrderService>();
        var invalid = string.Concat(Enumerable.Repeat("😀", 26));
        Assert.Equal(52, invalid.Length);
        if (field == "Category.Name")
        {
            var request = new UpsertCategoryRequest(invalid);
            if (put) await Assert.ThrowsAsync<ArgumentException>(() => service.UpdateCategoryAsync(id, request, CancellationToken.None));
            else await Assert.ThrowsAsync<ArgumentException>(() => service.CreateCategoryAsync(request, CancellationToken.None));
        }
        else
        {
            var request = new UpsertFileFormatRequest(field == "FileFormat.Name" ? invalid : "Synthetic sibling", field == "FileFormat.Extension" ? invalid : ".sibling");
            if (put) await Assert.ThrowsAsync<ArgumentException>(() => service.UpdateFileFormatAsync(id, request, CancellationToken.None));
            else await Assert.ThrowsAsync<ArgumentException>(() => service.CreateFileFormatAsync(request, CancellationToken.None));
        }
        Assert.Equal(before, await GraphAsync(app));
        Assert.DoesNotContain(scope.ServiceProvider.GetRequiredService<OrderDbContext>().ChangeTracker.Entries(), entry => entry.State is EntityState.Added or EntityState.Modified or EntityState.Deleted);
    }
    [Theory]
    [InlineData("Category.Name", false, null, HttpStatusCode.Unauthorized)]
    [InlineData("Category.Name", false, OrderPermissions.CatalogRead, HttpStatusCode.Forbidden)]
    [InlineData("Category.Name", true, null, HttpStatusCode.Unauthorized)]
    [InlineData("Category.Name", true, OrderPermissions.CatalogRead, HttpStatusCode.Forbidden)]
    [InlineData("FileFormat.Extension", false, null, HttpStatusCode.Unauthorized)]
    [InlineData("FileFormat.Extension", false, OrderPermissions.CatalogRead, HttpStatusCode.Forbidden)]
    [InlineData("FileFormat.Extension", true, null, HttpStatusCode.Unauthorized)]
    [InlineData("FileFormat.Extension", true, OrderPermissions.CatalogRead, HttpStatusCode.Forbidden)]
    public async Task AuthenticationPermissionPrecedeOverflow(string field, bool put, string? permission, HttpStatusCode expected)
    {
        await using var app = await fixture.AppAsync(null);
        using var writer = Client(app, OrderPermissions.CatalogWrite);
        var id = await SeedAsync(writer, field);
        var before = await GraphAsync(app);
        using var caller = Client(app, permission);
        using var response = await SendAsync(caller, field, put, id, new string('ก', 51));
        Assert.Equal(expected, response.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }
    [Theory]
    [InlineData("Category.Name")]
    [InlineData("FileFormat.Extension")]
    public async Task MissingTargetKeeps404BeforeLengthValidation(string field)
    {
        await using var app = await fixture.AppAsync(null);
        using var writer = Client(app, OrderPermissions.CatalogWrite);
        await SeedAsync(writer, field);
        var before = await GraphAsync(app);
        using var response = await SendAsync(writer, field, true, int.MaxValue, new string('ก', 51));
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }
    private HttpClient Client(WebApplicationFactory<Program> app, string? permission)
    {
        var client = app.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(45);
        if (permission is not null) client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.Token(permission));
        return client;
    }
    private static string Route(string field) => field == "Category.Name" ? "/orders/categories" : "/orders/fileformats";
    private static string? FieldValue(CatalogValue value, string field) => field == "FileFormat.Extension" ? value.Extension : value.Name;
    private sealed record CatalogValue(int Id, string? Name, string? Extension);
    private static async Task<CatalogValue> ValueAsync(HttpResponseMessage response, string field)
    {
        if (field == "Category.Name")
        {
            var value = (await response.Content.ReadFromJsonAsync<CategoryResponse>())!;
            return new(value.Id, value.Name, null);
        }
        var format = (await response.Content.ReadFromJsonAsync<FileFormatResponse>())!;
        return new(format.Id, format.Name, format.Extension);
    }
    private static async Task<CatalogValue> ReadAsync(HttpClient reader, string field, int id)
    {
        using var response = await reader.GetAsync(Route(field) + "/" + id);
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        return await ValueAsync(response, field);
    }
    private static Task<HttpResponseMessage> SendAsync(HttpClient client, string field, bool put, int id, string? literal)
    {
        var payload = new Dictionary<string, object?> { ["Name"] = field == "FileFormat.Extension" ? "Synthetic sibling" : literal };
        if (field != "Category.Name") payload["Extension"] = field == "FileFormat.Name" ? ".sibling" : literal;
        return put ? client.PutAsJsonAsync(Route(field) + "/" + id, payload) : client.PostAsJsonAsync(Route(field), payload);
    }
    private static async Task<int> SeedAsync(HttpClient writer, string field)
    {
        using var category = await SendAsync(writer, "Category.Name", false, 0, "Synthetic category");
        Assert.Equal(HttpStatusCode.Created, category.StatusCode);
        var categoryId = (await ValueAsync(category, "Category.Name")).Id;
        using var process = await writer.PostAsJsonAsync("/orders/processes", new UpsertProcessRequest(categoryId, "Synthetic process"));
        Assert.Equal(HttpStatusCode.Created, process.StatusCode);
        using var format = await SendAsync(writer, "FileFormat.Name", false, 0, "Synthetic format");
        Assert.Equal(HttpStatusCode.Created, format.StatusCode);
        return field == "Category.Name" ? categoryId : (await ValueAsync(format, "FileFormat.Name")).Id;
    }
    private static async Task AssertPhysicalAsync(WebApplicationFactory<Program> app, string field, int id, string? expected)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        if (field == "Category.Name") Assert.Equal(expected, (await db.Categories.AsNoTracking().SingleAsync(row => row.Id == id)).Name);
        else
        {
            var row = await db.FileFormats.AsNoTracking().SingleAsync(row => row.Id == id);
            Assert.Equal(expected, field == "FileFormat.Name" ? row.Name : row.Extension);
        }
    }
    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var status = scope.ServiceProvider.GetRequiredService<OrderStatusDbContext>();
        return JsonSerializer.Serialize(new
        {
            statuses = await status.Statuses.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            transitions = await status.Transitions.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            history = await status.History.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            categories = await db.Categories.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            processes = await db.Processes.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            orders = await db.Orders.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            files = await db.Files.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            formats = await db.FileFormats.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            intents = await db.DeletionIntents.AsNoTracking().OrderBy(row => row.OrderId).ToArrayAsync(lifetime.Token),
        });
    }
}
