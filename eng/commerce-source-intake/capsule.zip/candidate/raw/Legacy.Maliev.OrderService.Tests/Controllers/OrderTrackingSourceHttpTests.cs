using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.OrderService.Api.Authorization;
using Legacy.Maliev.OrderService.Application.Interfaces;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderTrackingSourceHttpTests(OrderDeletionReadinessFixture fixture) : IClassFixture<OrderDeletionReadinessFixture>
{
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task Utf16BoundaryPersistsAndOverflowPreservesEntireGraph(bool put, bool supplementary)
    {
        await using var app = await fixture.AppAsync(null);
        var (process, existing) = await SeedAsync(app);
        using var writer = Client(app, put ? OrderPermissions.Update : OrderPermissions.Create);
        using var reader = Client(app, OrderPermissions.Read);
        var exact = supplementary ? string.Concat(Enumerable.Repeat("😀", 124)) + "  " : new string('ก', 248) + "  ";
        Assert.Equal(250, exact.Length);
        using var valid = await SendAsync(writer, put, existing, Request(process, exact));
        Assert.Equal(put ? HttpStatusCode.NoContent : HttpStatusCode.Created, valid.StatusCode);
        var id = put ? existing.Id : (await valid.Content.ReadFromJsonAsync<OrderResponse>())!.Id;
        var readback = (await reader.GetFromJsonAsync<OrderResponse>($"/orders/{id}"))!;
        Assert.Equal(exact, readback.TrackingNumber);
        await AssertPhysicalAsync(app, id, exact);
        var before = await GraphAsync(app);
        using var invalid = await SendAsync(writer, put, readback, Request(process, exact + "ก"));
        Assert.Equal(HttpStatusCode.BadRequest, invalid.StatusCode);
        Assert.Contains("TrackingNumber", (await invalid.Content.ReadFromJsonAsync<Microsoft.AspNetCore.Mvc.ValidationProblemDetails>())!.Errors.Keys);
        Assert.Equal(before, await GraphAsync(app));
        Assert.Equal(readback, await reader.GetFromJsonAsync<OrderResponse>($"/orders/{id}"));
    }
    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData(" ก padded ")]
    public async Task NullEmptyPaddingCreateAndClearUpdate(string? literal)
    {
        await using var app = await fixture.AppAsync(null);
        var (process, existing) = await SeedAsync(app);
        using var creator = Client(app, OrderPermissions.Create);
        using var updater = Client(app, OrderPermissions.Update);
        using var reader = Client(app, OrderPermissions.Read);
        using var create = await SendAsync(creator, false, existing, Request(process, literal));
        Assert.Equal(HttpStatusCode.Created, create.StatusCode);
        Assert.NotNull(create.Headers.Location);
        var created = (await create.Content.ReadFromJsonAsync<OrderResponse>())!;
        Assert.Equal(literal, created.TrackingNumber);
        Assert.Equal(created, await reader.GetFromJsonAsync<OrderResponse>(create.Headers.Location));
        await AssertPhysicalAsync(app, created.Id, literal);
        using var update = await SendAsync(updater, true, existing, Request(process, literal));
        Assert.Equal(HttpStatusCode.NoContent, update.StatusCode);
        Assert.Equal(literal, (await reader.GetFromJsonAsync<OrderResponse>($"/orders/{existing.Id}"))!.TrackingNumber);
        await AssertPhysicalAsync(app, existing.Id, literal);
    }
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task DirectServiceOverflowRefusesWholeGraphMutation(bool put)
    {
        await using var app = await fixture.AppAsync(null);
        var (process, existing) = await SeedAsync(app);
        var before = await GraphAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var service = scope.ServiceProvider.GetRequiredService<IOrderService>();
        var request = Request(process, string.Concat(Enumerable.Repeat("😀", 126)));
        if (put) await Assert.ThrowsAsync<ArgumentException>(() => service.UpdateOrderAsync(existing.Id, request, null, CancellationToken.None));
        else await Assert.ThrowsAsync<ArgumentException>(() => service.CreateOrderAsync(request, CancellationToken.None));
        Assert.Equal(before, await GraphAsync(app));
        Assert.DoesNotContain(scope.ServiceProvider.GetRequiredService<OrderDbContext>().ChangeTracker.Entries(), entry => entry.State is EntityState.Added or EntityState.Modified or EntityState.Deleted);
    }
    private HttpClient Client(WebApplicationFactory<Program> app, string permission)
    {
        var client = app.CreateClient();
        client.Timeout = TimeSpan.FromSeconds(45);
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.Token(permission));
        return client;
    }
    private static UpsertOrderRequest Request(int process, string? tracking) => OrderTrackingControllerSourceTests.Request(tracking) with { ProcessId = process };
    private static Task<HttpResponseMessage> SendAsync(HttpClient writer, bool put, OrderResponse existing, UpsertOrderRequest request)
    {
        var message = new HttpRequestMessage(put ? HttpMethod.Put : HttpMethod.Post, put ? $"/orders/{existing.Id}" : "/orders") { Content = JsonContent.Create(request) };
        if (put && existing.ModifiedDate is { } modified)
            message.Headers.Add("X-Expected-Modified-Date", new DateTimeOffset(DateTime.SpecifyKind(modified, DateTimeKind.Utc)).ToString("O", System.Globalization.CultureInfo.InvariantCulture));
        return SendAndDisposeAsync(writer, message);
    }
    private static async Task<HttpResponseMessage> SendAndDisposeAsync(HttpClient writer, HttpRequestMessage message)
    {
        using (message) return await writer.SendAsync(message);
    }
    private static async Task<(int Process, OrderResponse Existing)> SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var process = new Process { Name = "Synthetic process", Category = new Category { Name = "Synthetic category" } };
        var order = new Order { Name = "Synthetic existing", TrackingNumber = "Synthetic prior", Process = process, Quantity = 1, Manufactured = 0,
            AllowCancellation = false, AllowPayment = false, AllowSocialMedia = false, CreatedDate = new DateTime(2026, 10, 7), ModifiedDate = new DateTime(2026, 10, 7) };
        db.Add(order);
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await db.SaveChangesAsync(lifetime.Token);
        return (process.Id, new OrderResponse(order.Id, null, null, order.Name, null, process.Id, null, null, null, 1, 0, order.Remaining, null, null, order.Subtotal, null, null, null, null, order.Turnaround, null, false, false, false, order.TrackingNumber, order.CreatedDate, order.ModifiedDate));
    }
    private static async Task AssertPhysicalAsync(WebApplicationFactory<Program> app, int id, string? expected)
    {
        await using var scope = app.Services.CreateAsyncScope();
        Assert.Equal(expected, (await scope.ServiceProvider.GetRequiredService<OrderDbContext>().Orders.AsNoTracking().SingleAsync(row => row.Id == id)).TrackingNumber);
    }
    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var status = scope.ServiceProvider.GetRequiredService<OrderStatusDbContext>();
        return JsonSerializer.Serialize(new
        {
            statuses = await status.Statuses.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            transitions = await status.Transitions.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            history = await status.History.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            categories = await db.Categories.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            processes = await db.Processes.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            orders = await db.Orders.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            files = await db.Files.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            formats = await db.FileFormats.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(lifetime.Token),
            intents = await db.DeletionIntents.AsNoTracking().OrderBy(row => row.OrderId).ToArrayAsync(lifetime.Token),
        });
    }
}
