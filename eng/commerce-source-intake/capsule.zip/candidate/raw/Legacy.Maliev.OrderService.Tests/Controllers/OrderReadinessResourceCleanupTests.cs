namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderReadinessResourceCleanupTests
{
    [Theory]
    [InlineData(false, false, false)]
    [InlineData(true, false, false)]
    [InlineData(false, true, false)]
    [InlineData(false, false, true)]
    [InlineData(true, true, true)]
    public async Task CleanupAttemptsEveryOwnedResourceAndRetainsEveryFailure(bool postgresFails, bool redisFails, bool keyFails)
    {
        var disposed = new List<string>();
        var expected = new List<Exception>();
        Task DisposeAsync(string resource, bool fails)
        {
            disposed.Add(resource);
            if (!fails) return Task.CompletedTask;
            var failure = new InvalidOperationException(resource);
            expected.Add(failure);
            return Task.FromException(failure);
        }

        var cleanup = OwnedOrderTestContainers.CleanupAsync(
            () => DisposeAsync("postgres", postgresFails),
            () => DisposeAsync("redis", redisFails),
            () =>
            {
                disposed.Add("key");
                if (keyFails)
                {
                    var failure = new InvalidOperationException("key");
                    expected.Add(failure);
                    throw failure;
                }
                return Task.CompletedTask;
            });
        if (postgresFails || redisFails || keyFails)
        {
            var failure = await Assert.ThrowsAsync<AggregateException>(() => cleanup);
            Assert.Equal(expected, failure.InnerExceptions);
        }
        else await cleanup;
        Assert.Equal(["postgres", "redis", "key"], disposed);
    }
}
