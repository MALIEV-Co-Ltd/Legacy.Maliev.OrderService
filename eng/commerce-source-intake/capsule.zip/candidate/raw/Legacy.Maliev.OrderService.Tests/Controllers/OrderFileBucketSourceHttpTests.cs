using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Legacy.Maliev.OrderService.Api.Authorization;
using Legacy.Maliev.OrderService.Application.Interfaces;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Time.Testing;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderFileBucketSourceHttpTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task NormalizedBoundary_DeduplicatesWithinOwnerAndPreservesUnboundedObjectName(bool supplementary)
    {
        var clock = new FakeTimeProvider(new DateTimeOffset(2026, 10, 7, 12, 0, 0, TimeSpan.Zero));
        await using var app = await fixture.AppAsync(null, configure: services =>
        {
            services.RemoveAll<TimeProvider>();
            services.AddSingleton<TimeProvider>(clock);
        });
        var firstOwner = await SeedAsync(app);
        var secondOwner = await SeedAsync(app);
        var exact = Boundary(supplementary);
        var objectName = new string('ก', 200) + ".step";
        using var writer = Client(app, OrderPermissions.FilesWrite);
        using var reader = Client(app, OrderPermissions.FilesRead);
        using var first = await CreateAsync(writer, firstOwner, "  " + exact + "  ", "  " + objectName + "  ");
        Assert.Equal(HttpStatusCode.Created, first.StatusCode);
        var original = (await first.Content.ReadFromJsonAsync<OrderFileResponse>())!;
        Assert.Equal(exact, original.Bucket);
        Assert.Equal(objectName, original.ObjectName);
        clock.Advance(TimeSpan.FromSeconds(1));
        using var duplicate = await CreateAsync(writer, firstOwner, exact, objectName);
        Assert.Equal(HttpStatusCode.Created, duplicate.StatusCode);
        Assert.Equal(original, await duplicate.Content.ReadFromJsonAsync<OrderFileResponse>());
        using var sibling = await CreateAsync(writer, secondOwner, exact, objectName);
        Assert.Equal(HttpStatusCode.Created, sibling.StatusCode);
        var siblingRow = (await sibling.Content.ReadFromJsonAsync<OrderFileResponse>())!;
        Assert.NotEqual(original.Id, siblingRow.Id);
        using var update = await writer.PutAsJsonAsync($"/orders/files/{original.Id}", new UpsertOrderFileRequest(secondOwner, "  " + exact + "  ", "  " + objectName + " revision  "));
        Assert.Equal(HttpStatusCode.NoContent, update.StatusCode);
        var current = (await reader.GetFromJsonAsync<OrderFileResponse>($"/orders/files/{original.Id}"))!;
        Assert.Equal(exact, current.Bucket);
        Assert.Equal(objectName + " revision", current.ObjectName);
        Assert.Equal(secondOwner, current.OrderId);
        Assert.Equal(original.CreatedDate, current.CreatedDate);
        Assert.True(current.ModifiedDate > original.ModifiedDate);
        await using var scope = app.Services.CreateAsyncScope();
        var rows = await scope.ServiceProvider.GetRequiredService<OrderDbContext>().Files.AsNoTracking().ToArrayAsync();
        Assert.Equal(2, rows.Length);
        Assert.Equal(current, Response(Assert.Single(rows, x => x.Id == original.Id)));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task OverflowAt51_RejectsCreateAndUpdateBeforeMutation(bool supplementary)
    {
        await using var app = await fixture.AppAsync(null);
        var owner = await SeedAsync(app);
        using var writer = Client(app, OrderPermissions.FilesWrite);
        using var created = await CreateAsync(writer, owner, "original", "original.step");
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var original = (await created.Content.ReadFromJsonAsync<OrderFileResponse>())!;
        var invalid = Boundary(supplementary) + "ก";
        Assert.Equal(51, invalid.Length);
        var before = await GraphAsync(app);
        using var create = await CreateAsync(writer, owner, "  " + invalid + "  ", "different.step");
        using var update = await writer.PutAsJsonAsync($"/orders/files/{original.Id}", new UpsertOrderFileRequest(owner, invalid, "changed.step"));
        Assert.Equal(HttpStatusCode.BadRequest, create.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData("create")]
    [InlineData("file")]
    [InlineData("destination")]
    public async Task MissingOwnerOrRow_PrecedesOverflowValidation(string operation)
    {
        await using var app = await fixture.AppAsync(null);
        var owner = await SeedAsync(app);
        using var writer = Client(app, OrderPermissions.FilesWrite);
        using var created = await CreateAsync(writer, owner, "original", "original.step");
        var original = (await created.Content.ReadFromJsonAsync<OrderFileResponse>())!;
        var before = await GraphAsync(app);
        var invalid = new string('ก', 51);
        using var response = operation == "create"
            ? await CreateAsync(writer, 999999, invalid, "changed.step")
            : await writer.PutAsJsonAsync($"/orders/files/{(operation == "file" ? 999999 : original.Id)}", new UpsertOrderFileRequest(999999, invalid, "changed.step"));
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData("\t")]
    public async Task BlankBucket_RemainsRequiredWithoutMutation(string blank)
    {
        await using var app = await fixture.AppAsync(null);
        var owner = await SeedAsync(app);
        using var writer = Client(app, OrderPermissions.FilesWrite);
        using var created = await CreateAsync(writer, owner, "original", "original.step");
        var original = (await created.Content.ReadFromJsonAsync<OrderFileResponse>())!;
        var before = await GraphAsync(app);
        using var create = await CreateAsync(writer, owner, blank, "changed.step");
        using var update = await writer.PutAsJsonAsync($"/orders/files/{original.Id}", new UpsertOrderFileRequest(owner, blank, "changed.step"));
        Assert.Equal(HttpStatusCode.BadRequest, create.StatusCode);
        Assert.Equal(HttpStatusCode.BadRequest, update.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task Authorization_PrecedesMutation(bool authenticated)
    {
        await using var app = await fixture.AppAsync(null);
        var owner = await SeedAsync(app);
        using var client = app.CreateClient();
        if (authenticated) client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.Token(OrderPermissions.Read));
        using var response = await CreateAsync(client, owner, new string('ก', 51), "changed.step");
        Assert.Equal(authenticated ? HttpStatusCode.Forbidden : HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.Empty(await RowsAsync(app));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData("overflow")]
    public async Task DirectWrites_RejectInvalidBucketAndPreserveMissingPrecedence(string? input)
    {
        await using var app = await fixture.AppAsync(null);
        var owner = await SeedAsync(app);
        await using var scope = app.Services.CreateAsyncScope();
        var service = scope.ServiceProvider.GetRequiredService<IOrderService>();
        var original = (await service.CreateFileAsync(owner, "original", "original.step", default))!;
        var before = await GraphAsync(app);
        var invalid = input == "overflow" ? new string('ก', 51) : input;
        await Assert.ThrowsAsync<ArgumentException>(() => service.CreateFileAsync(owner, invalid!, "changed.step", default));
        await Assert.ThrowsAsync<ArgumentException>(() => service.UpdateFileAsync(original.Id, new UpsertOrderFileRequest(owner, invalid!, "changed.step"), default));
        Assert.Null(await service.CreateFileAsync(999999, invalid!, "changed.step", default));
        Assert.False(await service.UpdateFileAsync(999999, new UpsertOrderFileRequest(owner, invalid!, "changed.step"), default));
        Assert.False(await service.UpdateFileAsync(original.Id, new UpsertOrderFileRequest(999999, invalid!, "changed.step"), default));
        Assert.Equal(before, await GraphAsync(app));
        Assert.DoesNotContain(scope.ServiceProvider.GetRequiredService<OrderDbContext>().ChangeTracker.Entries(), entry => entry.State is EntityState.Modified or EntityState.Added or EntityState.Deleted);
    }

    private static string Boundary(bool supplementary) => supplementary ? string.Concat(Enumerable.Repeat("😀", 25)) : new string('ก', 50);
    private HttpClient Client(WebApplicationFactory<Program> app, string permission)
    {
        var client = app.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.Token(permission));
        return client;
    }
    private static Task<HttpResponseMessage> CreateAsync(HttpClient client, int owner, string bucket, string objectName) => client.PostAsync($"/orders/{owner}/files?bucket={Uri.EscapeDataString(bucket)}&objectName={Uri.EscapeDataString(objectName)}", null);
    private static OrderFileResponse Response(OrderFile row) => new(row.Id, row.OrderId, row.Bucket, row.ObjectName, row.CreatedDate, row.ModifiedDate);
    private static async Task<OrderFileResponse[]> RowsAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        return (await scope.ServiceProvider.GetRequiredService<OrderDbContext>().Files.AsNoTracking().OrderBy(x => x.Id).ToArrayAsync()).Select(Response).ToArray();
    }
    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var context = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var rows = new List<string>();
        foreach (var table in new[] { "Category", "FileFormat", "Process", "Order", "OrderFile", "OrderDeletionIntent" })
        {
            var sql = $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') AS \"Value\" FROM public.\"{table}\" r";
            rows.Add(table + ":" + await context.Database.SqlQueryRaw<string>(sql).SingleAsync(lifetime.Token));
        }
        return string.Join("\n", rows);
    }

    private static async Task<int> SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var context = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var row = new Order { Name = "Synthetic bucket parent", Quantity = 1, Manufactured = 0, Process = new Process { Name = "Synthetic process", Category = new Category { Name = "Synthetic category" } } };
        context.Orders.Add(row);
        await context.SaveChangesAsync();
        return row.Id;
    }
}
