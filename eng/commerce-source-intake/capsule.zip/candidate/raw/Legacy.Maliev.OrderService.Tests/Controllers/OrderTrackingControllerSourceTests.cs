using System.ComponentModel.DataAnnotations;
using Legacy.Maliev.OrderService.Api.Controllers;
using Legacy.Maliev.OrderService.Application.Interfaces;
using Legacy.Maliev.OrderService.Application.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderTrackingControllerSourceTests
{
    [Theory]
    [InlineData(false, false)]
    [InlineData(false, true)]
    [InlineData(true, false)]
    [InlineData(true, true)]
    public async Task OverflowRefusesBeforeAnyIdempotencyOrServiceCall(bool put, bool supplementary)
    {
        var service = new Mock<IOrderService>(MockBehavior.Strict);
        var idempotency = new Mock<IIdempotencyStore>(MockBehavior.Strict);
        var controller = new OrdersController(service.Object, idempotency.Object);
        var invalid = supplementary ? string.Concat(Enumerable.Repeat("😀", 126)) : new string('ก', 251);
        Assert.True(invalid.Length > 250);
        var response = put
            ? await controller.UpdateOrderAsync(42, Request(invalid), null, CancellationToken.None)
            : await controller.CreateOrderAsync(Request(invalid), "synthetic-key", CancellationToken.None);
        var bad = Assert.IsType<BadRequestObjectResult>(response);
        Assert.Equal(400, bad.StatusCode);
        Assert.Contains("TrackingNumber", Assert.IsType<ValidationProblemDetails>(bad.Value).Errors.Keys);
        service.VerifyNoOtherCalls();
        idempotency.VerifyNoOtherCalls();
    }
    [Fact]
    public void ConstructorValidationMetadataPreservesNullableUtf16250()
    {
        var parameter = typeof(UpsertOrderRequest).GetConstructors().Single().GetParameters().Single(value => value.Name == "TrackingNumber");
        var attribute = Assert.Single(parameter.GetCustomAttributes(typeof(StringLengthAttribute), false).Cast<StringLengthAttribute>());
        Assert.Equal(250, attribute.MaximumLength);
        Assert.True(attribute.IsValid(null));
        Assert.True(attribute.IsValid(string.Empty));
        Assert.True(attribute.IsValid(string.Concat(Enumerable.Repeat("😀", 124)) + "  "));
        Assert.False(attribute.IsValid(string.Concat(Enumerable.Repeat("😀", 126))));
    }
    internal static UpsertOrderRequest Request(string? tracking) => new(
        CustomerId: null,
        EmployeeId: null,
        Name: "Synthetic name",
        Description: "Synthetic description",
        ProcessId: 1,
        MaterialId: null,
        SurfaceFinishId: null,
        ColorId: null,
        Quantity: 1,
        Manufactured: 0,
        UnitPrice: 1m,
        DiscountPercent: 0m,
        CurrencyId: null,
        LeadTime: null,
        PromisedDate: null,
        FinishedDate: null,
        Comment: null,
        AllowSocialMedia: false,
        AllowCancellation: false,
        AllowPayment: false,
        TrackingNumber: tracking);
}
