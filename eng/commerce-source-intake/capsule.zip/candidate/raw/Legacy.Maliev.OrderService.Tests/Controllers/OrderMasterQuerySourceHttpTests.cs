using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Legacy.Maliev.OrderService.Api.Authorization;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderMasterQuerySourceHttpTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    [Theory]
    [InlineData("/orders", "%", "1001,1003,1005,1006")]
    [InlineData("/orders/pending", "%", "1001,1003")]
    [InlineData("/orders/customers/7", "%", "1001,1005,1006")]
    [InlineData("/orders", "_", "1002")]
    [InlineData("/orders/pending", "_", "1002")]
    [InlineData("/orders/customers/7", "_", "1002")]
    public async Task ListSearch_SourceContainsTreatsPercentAndUnderscoreAsLiteral(string path, string search, string ids)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, path);
        using var response = await client.GetAsync($"{path}?search={Uri.EscapeDataString(search)}&index=1&size=10");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        var expected = ids.Split(',').Select(int.Parse).ToArray();
        Assert.Equal(expected, page.Items.Select(item => item.Id));
        Assert.Equal(expected.Length, page.TotalRecords);
        Assert.Equal(1, page.TotalPages);
        await AssertUnchangedAsync(app);
    }

    [Theory]
    [InlineData("/orders")]
    [InlineData("/orders/pending")]
    [InlineData("/orders/customers/7")]
    public async Task ListSearch_SourceRetainsSpacesAroundNonemptyLiteralText(string path)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, path);
        using var response = await client.GetAsync($"{path}?search=%20part%20&index=1&size=10");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        await AssertUnchangedAsync(app);
    }

    [Theory]
    [InlineData("/orders")]
    [InlineData("/orders/pending")]
    [InlineData("/orders/customers/7")]
    public async Task ListPage_SourceReturnsNotFoundBeyondLastSelectedRow(string path)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, path);
        using var response = await client.GetAsync($"{path}?index=100&size=1");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
        await AssertUnchangedAsync(app);
    }

    [Theory]
    [InlineData("/orders", "1001")]
    [InlineData("/orders", "001001")]
    [InlineData("/orders", " 1001 ")]
    [InlineData("/orders/pending", "1001")]
    [InlineData("/orders/pending", "001001")]
    [InlineData("/orders/pending", " 1001 ")]
    [InlineData("/orders/customers/7", "1001")]
    [InlineData("/orders/customers/7", "001001")]
    [InlineData("/orders/customers/7", " 1001 ")]
    public async Task ListSearch_KeepsExistingExclusiveIntegerBranch(string path, string search)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, path);
        using var response = await client.GetAsync($"{path}?search={Uri.EscapeDataString(search)}&size=10");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(1001, Assert.Single(page.Items).Id);
        Assert.Equal(1, page.TotalRecords);
        await AssertUnchangedAsync(app);
    }

    [Theory]
    [InlineData("track-only")]
    [InlineData("comment-only")]
    public async Task PendingSearch_KeepsOnlyNameAndDescriptionWhileRegularIncludesOtherFields(string search)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, "/orders");
        using var regular = await client.GetAsync($"/orders?search={search}&size=10");
        Assert.Equal(HttpStatusCode.OK, regular.StatusCode);
        Assert.Equal(1001, Assert.Single((await regular.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!.Items).Id);
        using var pending = await client.GetAsync($"/orders/pending?search={search}&size=10");
        Assert.Equal(HttpStatusCode.NotFound, pending.StatusCode);
        await AssertUnchangedAsync(app);
    }

    [Fact]
    public async Task LiteralThaiText_RemainsExactThroughHttpAndPostgreSql()
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, "/orders");
        const string search = "\u0e0a\u0e34\u0e49\u0e19\u0e07\u0e32\u0e19";
        using var response = await client.GetAsync($"/orders?search={Uri.EscapeDataString(search)}&size=10");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(1001, Assert.Single(page.Items).Id);
        Assert.EndsWith(search, page.Items[0].Name, StringComparison.Ordinal);
        await AssertUnchangedAsync(app);
    }

    [Theory]
    [InlineData("/orders")]
    [InlineData("/orders/pending")]
    [InlineData("/orders/customers/7")]
    public async Task MatchingDeletedLifetime_StillConflictsBeforeEmptyPageSelection(string path)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        await using (var scope = app.Services.CreateAsyncScope())
        {
            var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
            var now = DateTime.UtcNow;
            database.DeletionIntents.Add(new OrderDeletionIntent { OrderId = 1001, DeletionId = Guid.NewGuid(), RequestedAtUtc = now, NextAttemptAtUtc = now });
            await database.SaveChangesAsync();
        }
        using var client = Client(app, path);
        using var response = await client.GetAsync($"{path}?search=%25&index=100&size=1");
        Assert.Equal(HttpStatusCode.Conflict, response.StatusCode);
        Assert.DoesNotContain("Fixture%part", await response.Content.ReadAsStringAsync(), StringComparison.Ordinal);
        await using var readScope = app.Services.CreateAsyncScope();
        var orders = readScope.ServiceProvider.GetRequiredService<OrderDbContext>();
        Assert.Equal(6, await orders.Orders.CountAsync());
        Assert.Single(await orders.DeletionIntents.ToArrayAsync());
        Assert.Empty(await readScope.ServiceProvider.GetRequiredService<OrderStatusDbContext>().History.ToArrayAsync());
    }

    [Theory]
    [InlineData("/orders", 263)]
    [InlineData("/orders/pending", 262)]
    [InlineData("/orders/customers/7", 262)]
    public async Task OmittedSize_UsesFilteredCountBeyondBothFormerLimits(string path, int expectedCount)
    {
        await using var app = await fixture.AppAsync(null);
        await using (var scope = app.Services.CreateAsyncScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
            var process = new Process { Name = "Size process", Category = new Category { Name = "Size category" } };
            var day = new DateTime(2026, 10, 10);
            for (var id = 1; id <= 261; id++)
                db.Orders.Add(new Order { Id = id, CustomerId = 7, Name = "Selected size", Process = process, Quantity = 1, PromisedDate = day });
            db.Orders.AddRange(
                new Order { Id = 262, CustomerId = 8, Name = "Selected size", Process = process, Quantity = 1, PromisedDate = day },
                new Order { Id = 263, CustomerId = 7, Name = "Selected size", Process = process, Quantity = 1, PromisedDate = day, FinishedDate = day },
                new Order { Id = 264, CustomerId = 7, Name = "Excluded", Process = process, Quantity = 1, PromisedDate = day });
            await db.SaveChangesAsync();
        }
        using var client = Client(app, path);
        var expected = Enumerable.Range(1, 263).Where(id =>
            !(path.EndsWith("pending", StringComparison.Ordinal) && id == 263)
            && !(path.Contains("customers", StringComparison.Ordinal) && id == 262)).ToArray();
        using var response = await client.GetAsync($"{path}?search=selected&index=1");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(expected, page.Items.Select(item => item.Id));
        Assert.Equal(expectedCount, page.TotalRecords);
        Assert.Equal(1, page.TotalPages);
        Assert.Equal(1, page.PageIndex);
        Assert.False(page.HasNextPage);
        Assert.False(page.HasPreviousPage);
        using var beyond = await client.GetAsync($"{path}?search=selected&index=2");
        Assert.Equal(HttpStatusCode.NotFound, beyond.StatusCode);
        using var explicitSize = await client.GetAsync($"{path}?search=selected&index=2&size=7");
        Assert.Equal(HttpStatusCode.OK, explicitSize.StatusCode);
        var explicitPage = (await explicitSize.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(expected.Skip(7).Take(7), explicitPage.Items.Select(item => item.Id));
        Assert.Equal(expectedCount, explicitPage.TotalRecords);
        Assert.Equal((int)Math.Ceiling(expectedCount / 7d), explicitPage.TotalPages);
        await using var readScope = app.Services.CreateAsyncScope();
        var stored = readScope.ServiceProvider.GetRequiredService<OrderDbContext>();
        Assert.Equal(264, await stored.Orders.CountAsync());
        Assert.Empty(await stored.DeletionIntents.ToArrayAsync());
        Assert.Empty(await readScope.ServiceProvider.GetRequiredService<OrderStatusDbContext>().History.ToArrayAsync());
    }

    [Theory]
    [InlineData(7, "", "1001,1002,1004,1005,1006")]
    [InlineData(8, "", "1003")]
    [InlineData(7, "%", "1001,1005,1006")]
    [InlineData(999, "", "")]
    public async Task GeneralList_CustomerIdQueryFiltersBeforeSearchAndPaging(int customerId, string search, string ids)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, "/orders");
        using var response = await client.GetAsync($"/orders?customerId={customerId}&search={Uri.EscapeDataString(search)}&index=1&size=10");
        Assert.Equal(ids.Length == 0 ? HttpStatusCode.NotFound : HttpStatusCode.OK, response.StatusCode);
        if (ids.Length != 0)
        {
            var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
            var expected = ids.Split(',').Select(int.Parse).ToArray();
            Assert.Equal(expected, page.Items.Select(item => item.Id));
            Assert.All(page.Items, item => Assert.Equal(customerId, item.CustomerId));
            Assert.Equal(expected.Length, page.TotalRecords);
            Assert.Equal(1, page.TotalPages);
        }
        await AssertUnchangedAsync(app);
    }

    [Fact]
    public async Task GeneralList_CustomerIdQueryStillRequiresGeneralReadPermission()
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = app.CreateClient();
        using var anonymous = await client.GetAsync("/orders?customerId=7");
        Assert.Equal(HttpStatusCode.Unauthorized, anonymous.StatusCode);
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.DeleteToken());
        using var denied = await client.GetAsync("/orders?customerId=7");
        Assert.Equal(HttpStatusCode.Forbidden, denied.StatusCode);
        await AssertUnchangedAsync(app);
    }

    [Fact]
    public async Task GeneralList_CustomerIdQueryPagesWithinFilteredRows()
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        using var client = Client(app, "/orders");
        using var response = await client.GetAsync("/orders?customerId=7&size=2&index=2");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var page = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(new[] { 1004, 1005 }, page.Items.Select(item => item.Id));
        Assert.All(page.Items, item => Assert.Equal(7, item.CustomerId));
        Assert.Equal(5, page.TotalRecords);
        Assert.Equal(3, page.TotalPages);
        Assert.Equal(2, page.PageIndex);
        Assert.True(page.HasNextPage);
        Assert.True(page.HasPreviousPage);
        await AssertUnchangedAsync(app);
    }

    private HttpClient Client(WebApplicationFactory<Program> app, string path)
    {
        var client = app.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",
            fixture.Token(path.Contains("/customers/", StringComparison.Ordinal) ? OrderPermissions.CustomerRead : OrderPermissions.Read));
        return client;
    }

    private static async Task SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var process = new Process { Name = "Source query process", Category = new Category { Name = "Source query category" } };
        var promised = new DateTime(2026, 10, 10);
        database.Orders.AddRange(
            new Order { Id = 1001, CustomerId = 7, Name = "Fixture%part\u0e0a\u0e34\u0e49\u0e19\u0e07\u0e32\u0e19", TrackingNumber = "track-only", Comment = "comment-only", PromisedDate = promised, Process = process, Quantity = 1 },
            new Order { Id = 1002, CustomerId = 7, Name = "Normalpart1001", Description = "detail_assembly", PromisedDate = promised, Process = process, Quantity = 1 },
            new Order { Id = 1003, CustomerId = 8, Name = "Other%part", PromisedDate = promised, Process = process, Quantity = 1 },
            new Order { Id = 1004, CustomerId = 7, Name = "Normal", Process = process, Quantity = 1 },
            new Order { Id = 1005, CustomerId = 7, Name = "Finished%part", PromisedDate = promised, FinishedDate = promised.AddDays(-1), Process = process, Quantity = 1 },
            new Order { Id = 1006, CustomerId = 7, Name = null, Description = null, TrackingNumber = "part203", Comment = "tracking%literal", PromisedDate = promised, Process = process, Quantity = 1 });
        await database.SaveChangesAsync();
    }

    private static async Task AssertUnchangedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var database = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        Assert.Equal(6, await database.Orders.CountAsync());
        Assert.Empty(await database.DeletionIntents.ToArrayAsync());
        Assert.Empty(await scope.ServiceProvider.GetRequiredService<OrderStatusDbContext>().History.ToArrayAsync());
    }
}
