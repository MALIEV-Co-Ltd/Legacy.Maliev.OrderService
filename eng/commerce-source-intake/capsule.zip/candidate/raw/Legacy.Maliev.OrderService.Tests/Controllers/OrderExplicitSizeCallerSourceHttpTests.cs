using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Legacy.Maliev.OrderService.Api.Authorization;
using Legacy.Maliev.OrderService.Application.Models;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Legacy.Maliev.OrderService.Tests.Controllers;

public sealed class OrderExplicitSizeCallerSourceHttpTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    [Theory]
    [InlineData("/orders", 1000, false)]
    [InlineData("/orders", 1000, true)]
    [InlineData("/orders", 1001, false)]
    [InlineData("/orders", 1001, true)]
    [InlineData("/orders/pending", 1000, false)]
    [InlineData("/orders/pending", 1000, true)]
    [InlineData("/orders/pending", 1001, false)]
    [InlineData("/orders/pending", 1001, true)]
    [InlineData("/orders/customers/7", 1000, false)]
    [InlineData("/orders/customers/7", 1000, true)]
    [InlineData("/orders/customers/7", 1001, false)]
    [InlineData("/orders/customers/7", 1001, true)]
    public async Task Explicit_positive_size_preserves_full_pages_sort_filters_and_employee_queue_rows(
        string path, int size, bool descending)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        var before = await GraphAsync(app);
        var ids = Enumerable.Range(1, 1002).Concat(path.Contains("/customers/", StringComparison.Ordinal) ? [] : new[] { 2001 })
            .Concat(path.EndsWith("pending", StringComparison.Ordinal) ? [] : new[] { 2002 }).ToArray();
        if (descending) Array.Reverse(ids);
        using var client = Client(app, path);
        var query = $"search=selected&size={size}" + (descending ? "&sort=OrderId_Descending" : "");
        using var response = await client.GetAsync($"{path}?{query}&index=1");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var first = (await response.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(ids.Take(size), first.Items.Select(row => row.Id));
        Assert.Equal(ids.Length, first.TotalRecords);
        Assert.Equal(2, first.TotalPages);
        Assert.Equal(1, first.PageIndex);
        Assert.True(first.HasNextPage);
        Assert.False(first.HasPreviousPage);
        Assert.Equal(7, first.Items.Single(row => row.Id == 251).EmployeeId);
        Assert.Null(first.Items.Single(row => row.Id == 300).EmployeeId);
        if (path.EndsWith("pending", StringComparison.Ordinal)) Assert.All(first.Items, row => Assert.Null(row.FinishedDate));
        if (path.Contains("/customers/", StringComparison.Ordinal)) Assert.All(first.Items, row => Assert.Equal(7, row.CustomerId));

        using var secondResponse = await client.GetAsync($"{path}?{query}&index=2");
        Assert.Equal(HttpStatusCode.OK, secondResponse.StatusCode);
        var second = (await secondResponse.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(ids.Skip(size), second.Items.Select(row => row.Id));
        Assert.Equal(ids.Length, second.TotalRecords);
        Assert.Equal(2, second.TotalPages);
        Assert.Equal(2, second.PageIndex);
        Assert.False(second.HasNextPage);
        Assert.True(second.HasPreviousPage);
        using var beyond = await client.GetAsync($"{path}?{query}&index=3");
        Assert.Equal(HttpStatusCode.NotFound, beyond.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    [Theory]
    [InlineData("/orders")]
    [InlineData("/orders/pending")]
    [InlineData("/orders/customers/7")]
    public async Task Explicit_large_size_keeps_auth_numeric_search_empty404_and_no_write_contracts(string path)
    {
        await using var app = await fixture.AppAsync(null);
        await SeedAsync(app);
        var before = await GraphAsync(app);
        using var anonymous = app.CreateClient();
        using var unauthorized = await anonymous.GetAsync($"{path}?size=1000");
        Assert.Equal(HttpStatusCode.Unauthorized, unauthorized.StatusCode);
        anonymous.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", fixture.DeleteToken());
        using var forbidden = await anonymous.GetAsync($"{path}?size=1000");
        Assert.Equal(HttpStatusCode.Forbidden, forbidden.StatusCode);
        using var client = Client(app, path);
        using var numeric = await client.GetAsync($"{path}?search=251&size=1000&index=1");
        Assert.Equal(HttpStatusCode.OK, numeric.StatusCode);
        var page = (await numeric.Content.ReadFromJsonAsync<PaginatedResponse<OrderResponse>>())!;
        Assert.Equal(251, Assert.Single(page.Items).Id);
        Assert.Equal(1, page.TotalRecords);
        Assert.Equal(1, page.TotalPages);
        using var empty = await client.GetAsync($"{path}?search=no-such-fixture&size=1000");
        Assert.Equal(HttpStatusCode.NotFound, empty.StatusCode);
        Assert.Equal(before, await GraphAsync(app));
    }

    private HttpClient Client(WebApplicationFactory<Program> app, string path)
    {
        var client = app.CreateClient();
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",
            fixture.Token(path.Contains("/customers/", StringComparison.Ordinal) ? OrderPermissions.CustomerRead : OrderPermissions.Read));
        return client;
    }

    private static async Task SeedAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var process = new Process { Name = "Explicit size process", Category = new Category { Name = "Explicit size category" } };
        var day = new DateTime(2026, 10, 10);
        for (var id = 1; id <= 1002; id++)
            db.Orders.Add(new Order { Id = id, CustomerId = 7, EmployeeId = id == 251 ? 7 : null,
                Name = "Selected fixture", Process = process, Quantity = 1, PromisedDate = day });
        db.Orders.AddRange(new Order { Id = 2001, CustomerId = 8, Name = "Selected fixture", Process = process, Quantity = 1, PromisedDate = day },
            new Order { Id = 2002, CustomerId = 7, Name = "Selected fixture", Process = process, Quantity = 1, PromisedDate = day, FinishedDate = day },
            new Order { Id = 2003, CustomerId = 7, Name = "Excluded sentinel", Process = process, Quantity = 1, PromisedDate = day });
        await db.SaveChangesAsync();
    }

    private static async Task<string> GraphAsync(WebApplicationFactory<Program> app)
    {
        await using var scope = app.Services.CreateAsyncScope();
        var db = scope.ServiceProvider.GetRequiredService<OrderDbContext>();
        var status = scope.ServiceProvider.GetRequiredService<OrderStatusDbContext>();
        return JsonSerializer.Serialize(new
        {
            Orders = await db.Orders.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(),
            Processes = await db.Processes.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(),
            Categories = await db.Categories.AsNoTracking().OrderBy(row => row.Id).ToArrayAsync(),
            Deletions = await db.DeletionIntents.AsNoTracking().ToArrayAsync(),
            History = await status.History.AsNoTracking().ToArrayAsync(),
        });
    }
}
