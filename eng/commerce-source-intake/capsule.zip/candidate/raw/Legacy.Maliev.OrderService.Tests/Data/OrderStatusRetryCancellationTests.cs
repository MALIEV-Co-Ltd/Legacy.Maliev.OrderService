using System.Diagnostics;
using System.Data.Common;
using System.Text.Json;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Tests.Controllers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Legacy.Maliev.OrderService.Tests.Data;

public sealed class OrderStatusRetryCancellationTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    private const string Previous = "20260721030107_FixTimestampColumnType";
    private const string Target = "20261007120000_RequireOrderStatusSourceStrings";

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ProductionRetryCancellationPreservesEntirePreimageAndReleasesSessionState(bool down)
    {
        using var cancellation = new CancellationTokenSource();
        using var observer = new RetryObserver(cancellation);
        await using var owned = await OpenAsync(down ? Target : Previous, observer);
        var context = owned.Context;
        Assert.True(context.Database.CreateExecutionStrategy().RetriesOnFailure);
        await SeedAsync(context);
        var before = await SnapshotAsync(context);
        var priorLockTimeout = await ScalarAsync<string>(context, "SHOW lock_timeout");
        var priorStatementTimeout = await ScalarAsync<string>(context, "SHOW statement_timeout");
        await using var blocker = new NpgsqlConnection(context.Database.GetConnectionString());
        using var setup = new CancellationTokenSource(TimeSpan.FromSeconds(15));
        await blocker.OpenAsync(setup.Token);
        await using var transaction = await blocker.BeginTransactionAsync(setup.Token);
        Task? migrating = null;
        try
        {
            await using var command = new NpgsqlCommand("LOCK TABLE public.\"OrderStatus\" IN ACCESS EXCLUSIVE MODE", blocker, transaction) { CommandTimeout = 10 };
            await command.ExecuteNonQueryAsync(setup.Token);
            observer.Arm();
            cancellation.CancelAfter(TimeSpan.FromSeconds(30));
            var watch = Stopwatch.StartNew();
            migrating = context.GetService<IMigrator>().MigrateAsync(down ? Previous : Target, cancellation.Token);
            var failure = await observer.FirstRetry.WaitAsync(TimeSpan.FromSeconds(15));
            Assert.Equal("55P03", failure.SqlState);
            Assert.True(cancellation.IsCancellationRequested);
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => migrating.WaitAsync(TimeSpan.FromSeconds(10)));
            Assert.InRange(watch.Elapsed, TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(25));
        }
        finally
        {
            await cancellation.CancelAsync();
            try
            {
                if (migrating is not null)
                {
                    try { await migrating.WaitAsync(TimeSpan.FromSeconds(10)); }
                    catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
                }
            }
            finally
            {
                using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                await transaction.RollbackAsync(cleanup.Token);
                observer.Disarm();
            }
        }

        Assert.Equal(before, await SnapshotAsync(context));
        Assert.Null(context.Database.CurrentTransaction);
        Assert.Equal(priorLockTimeout, await ScalarAsync<string>(context, "SHOW lock_timeout"));
        Assert.Equal(priorStatementTimeout, await ScalarAsync<string>(context, "SHOW statement_timeout"));
        Assert.Equal(0, await ScalarAsync<int>(context, "SELECT count(*)::int FROM pg_class WHERE relname='__OrderStatusSourceStringGuard' AND relnamespace=pg_my_temp_schema()"));
        await MigrateAsync(context, down ? Previous : Target);
        var after = await SnapshotAsync(context);
        Assert.Equal(before.Rows, after.Rows);
        Assert.NotEqual(before.Schema, after.Schema);
        Assert.NotEqual(before.History, after.History);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task AlreadyCanceledProductionMigrationPreservesPreimageAndCanResume(bool down)
    {
        await using var owned = await OpenAsync(down ? Target : Previous);
        var context = owned.Context;
        Assert.True(context.Database.CreateExecutionStrategy().RetriesOnFailure);
        await SeedAsync(context);
        var before = await SnapshotAsync(context);
        using var cancellation = new CancellationTokenSource();
        await cancellation.CancelAsync();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            context.GetService<IMigrator>().MigrateAsync(down ? Previous : Target, cancellation.Token));
        Assert.Equal(before, await SnapshotAsync(context));
        Assert.Null(context.Database.CurrentTransaction);
        await MigrateAsync(context, down ? Previous : Target);
        Assert.Equal(before.Rows, (await SnapshotAsync(context)).Rows);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ProductionRetryCompletesAfterOwnedBlockerReleaseWithoutRewritingRows(bool down)
    {
        using var cancellation = new CancellationTokenSource();
        using var observer = new RetryObserver(cancellation, cancelOnRetry: false);
        await using var owned = await OpenAsync(down ? Target : Previous, observer);
        var context = owned.Context;
        Assert.True(context.Database.CreateExecutionStrategy().RetriesOnFailure);
        await SeedAsync(context);
        var before = await SnapshotAsync(context);
        await using var blocker = new NpgsqlConnection(context.Database.GetConnectionString());
        using var setup = new CancellationTokenSource(TimeSpan.FromSeconds(15));
        await blocker.OpenAsync(setup.Token);
        await using var transaction = await blocker.BeginTransactionAsync(setup.Token);
        Task? migrating = null;
        try
        {
            try
            {
                await using var command = new NpgsqlCommand("LOCK TABLE public.\"OrderStatus\" IN ACCESS EXCLUSIVE MODE", blocker, transaction) { CommandTimeout = 10 };
                await command.ExecuteNonQueryAsync(setup.Token);
                observer.Arm();
                cancellation.CancelAfter(TimeSpan.FromSeconds(45));
                migrating = context.GetService<IMigrator>().MigrateAsync(down ? Previous : Target, cancellation.Token);
                var failure = await observer.FirstRetry.WaitAsync(TimeSpan.FromSeconds(15));
                Assert.Equal("55P03", failure.SqlState);
                Assert.False(cancellation.IsCancellationRequested);
                Assert.False(migrating.IsCompleted);
            }
            finally
            {
                using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(15));
                await transaction.RollbackAsync(cleanup.Token);
            }

            await (migrating ?? throw new InvalidOperationException("Migration was not started.")).WaitAsync(TimeSpan.FromSeconds(30));
            var after = await SnapshotAsync(context);
            Assert.Equal(before.Rows, after.Rows);
            Assert.NotEqual(before.Schema, after.Schema);
            Assert.NotEqual(before.History, after.History);
            Assert.Null(context.Database.CurrentTransaction);
            Assert.Equal(0, await ScalarAsync<int>(context, "SELECT count(*)::int FROM pg_class WHERE relname='__OrderStatusSourceStringGuard' AND relnamespace=pg_my_temp_schema()"));
            await MigrateAsync(context, down ? Previous : Target);
            Assert.Equal(after, await SnapshotAsync(context));
        }
        finally
        {
            observer.Disarm();
            await cancellation.CancelAsync();
            if (migrating is not null)
            {
                try { await migrating.WaitAsync(TimeSpan.FromSeconds(10)); }
                catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
            }
        }
    }

    private sealed class RetryObserver(CancellationTokenSource cancellation, bool cancelOnRetry = true) : ILoggerProvider
    {
        private readonly TaskCompletionSource<PostgresException> firstRetry = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private readonly CancellationTokenSource cancellationSource = cancellation;
        private readonly bool cancelsRetry = cancelOnRetry;
        private int armed;
        public Task<PostgresException> FirstRetry => firstRetry.Task;
        public void Arm() => Volatile.Write(ref armed, 1);
        public void Disarm() => Volatile.Write(ref armed, 0);
        public ILogger CreateLogger(string categoryName) => new RetryLogger(this);
        public void Dispose() => Disarm();

        private sealed class RetryLogger(RetryObserver owner) : ILogger
        {
            public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
            public bool IsEnabled(LogLevel logLevel) => true;
            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
            {
                if (Volatile.Read(ref owner.armed) == 1 && eventId.Id == CoreEventId.ExecutionStrategyRetrying.Id
                    && exception is PostgresException { SqlState: "55P03" } failure)
                {
                    if (owner.cancelsRetry) owner.cancellationSource.Cancel();
                    owner.firstRetry.TrySetResult(failure);
                }
            }
        }
    }
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task CancellationAfterRealSourceDdlRollsBackSchemaRowsAndHistoryBeforeResumption(bool down)
    {
        using var cancellation = new CancellationTokenSource();
        var interceptor = new CancelAfterSourceDdl(cancellation, down);
        await using var owned = await OpenAsync(down ? Target : Previous, interceptor: interceptor);
        var context = owned.Context;
        Assert.True(context.Database.CreateExecutionStrategy().RetriesOnFailure);
        await SeedAsync(context);
        var before = await SnapshotAsync(context);
        var priorLockTimeout = await ScalarAsync<string>(context, "SHOW lock_timeout");
        var priorStatementTimeout = await ScalarAsync<string>(context, "SHOW statement_timeout");
        interceptor.Armed = true;
        cancellation.CancelAfter(TimeSpan.FromSeconds(30));
        try
        {
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
                context.GetService<IMigrator>().MigrateAsync(down ? Previous : Target, cancellation.Token));
            Assert.True(interceptor.ObservedUncommittedDdl);
        }
        finally
        {
            interceptor.Armed = false;
            await cancellation.CancelAsync();
        }

        Assert.Equal(before, await SnapshotAsync(context));
        Assert.Null(context.Database.CurrentTransaction);
        Assert.Equal(priorLockTimeout, await ScalarAsync<string>(context, "SHOW lock_timeout"));
        Assert.Equal(priorStatementTimeout, await ScalarAsync<string>(context, "SHOW statement_timeout"));
        Assert.Equal(0, await ScalarAsync<int>(context, "SELECT count(*)::int FROM pg_class WHERE relname='__OrderStatusSourceStringGuard' AND relnamespace=pg_my_temp_schema()"));
        await MigrateAsync(context, down ? Previous : Target);
        var after = await SnapshotAsync(context);
        Assert.Equal(before.Rows, after.Rows);
        Assert.NotEqual(before.Schema, after.Schema);
        Assert.NotEqual(before.History, after.History);
    }

    private sealed class CancelAfterSourceDdl(CancellationTokenSource cancellation, bool down) : DbCommandInterceptor
    {
        public bool Armed { get; set; }
        public bool ObservedUncommittedDdl { get; private set; }
        public override async ValueTask<int> NonQueryExecutedAsync(DbCommand command, CommandExecutedEventData eventData, int result, CancellationToken cancellationToken = default)
        {
            if (!Armed || !command.CommandText.Contains("SET LOCAL lock_timeout = '5s';", StringComparison.Ordinal)
                || !command.CommandText.Contains("ALTER TABLE public.\"OrderStatus\"", StringComparison.Ordinal)) return result;
            Assert.False(ObservedUncommittedDdl);
            var connection = Assert.IsType<NpgsqlConnection>(command.Connection);
            var transaction = Assert.IsType<NpgsqlTransaction>(command.Transaction);
            using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(10));
            await using var probe = new NpgsqlCommand("""
                SELECT jsonb_build_object(
                    'nameType',(SELECT format_type(atttypid,atttypmod) FROM pg_attribute WHERE attrelid='public."OrderStatus"'::regclass AND attname='Name' AND NOT attisdropped),
                    'nameRequired',(SELECT attnotnull FROM pg_attribute WHERE attrelid='public."OrderStatus"'::regclass AND attname='Name' AND NOT attisdropped),
                    'sourceChecks',(SELECT count(*) FROM pg_constraint WHERE conrelid='public."OrderStatus"'::regclass AND conname IN ('CK_OrderStatus_Name_SourceLength','CK_OrderStatus_Description_SourceLength')),
                    'targetHistory',EXISTS(SELECT 1 FROM public."__EFMigrationsHistory" WHERE "MigrationId"='20261007120000_RequireOrderStatusSourceStrings')
                )::text
                """, connection, transaction) { CommandTimeout = 10 };
            using var physical = JsonDocument.Parse(Assert.IsType<string>(await probe.ExecuteScalarAsync(lifetime.Token)));
            Assert.Equal(down ? "character varying(50)" : "text", physical.RootElement.GetProperty("nameType").GetString());
            Assert.Equal(!down, physical.RootElement.GetProperty("nameRequired").GetBoolean());
            Assert.Equal(down ? 0 : 2, physical.RootElement.GetProperty("sourceChecks").GetInt32());
            Assert.Equal(down, physical.RootElement.GetProperty("targetHistory").GetBoolean());
            ObservedUncommittedDdl = true;
            cancellation.Cancel();
            return result;
        }
    }

    private async Task<OwnedScope> OpenAsync(string? target = null, RetryObserver? observer = null, DbCommandInterceptor? interceptor = null)
    {
        var rootApp = await fixture.AppAsync(null, configure: interceptor is null ? null : services =>
            services.ConfigureDbContext<OrderStatusDbContext>(options => options.AddInterceptors(interceptor)));
        var app = rootApp;
        if (observer is not null)
            app = rootApp.WithWebHostBuilder(builder => builder.ConfigureLogging(logging =>
                logging.AddFilter("Microsoft.EntityFrameworkCore.Infrastructure", LogLevel.Information).AddProvider(observer)));
        AsyncServiceScope? scope = null;
        try
        {
            scope = app.Services.CreateAsyncScope();
            var context = scope.Value.ServiceProvider.GetRequiredService<OrderStatusDbContext>();
            var authority = new NpgsqlConnectionStringBuilder(context.Database.GetConnectionString());
            var database = authority.Database;
            if (database is null || !database.StartsWith("owned_", StringComparison.Ordinal)
                || !Guid.TryParseExact(database[6..], "N", out _)
                || authority.Host is not ("localhost" or "127.0.0.1") || authority.Pooling)
                throw new InvalidOperationException("Require the fixture-owned isolated status database.");
            context.Database.SetCommandTimeout(40);
            using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
            await context.Database.OpenConnectionAsync(lifetime.Token);
            if (target is not null) await MigrateAsync(context, target);
            return new OwnedScope(rootApp, scope.Value, context);
        }
        catch
        {
            try { if (scope is { } opened) await opened.DisposeAsync(); }
            finally { await rootApp.DisposeAsync(); }
            throw;
        }
    }

    private sealed class OwnedScope(WebApplicationFactory<Program> app, AsyncServiceScope scope, OrderStatusDbContext context) : IAsyncDisposable
    {
        public OrderStatusDbContext Context => context;
        public async ValueTask DisposeAsync()
        {
            try { await scope.DisposeAsync(); }
            finally { await app.DisposeAsync(); }
        }
    }

    private static Task SeedAsync(OrderStatusDbContext context) => ExecuteAsync(context, """
        INSERT INTO public."OrderStatus" ("ID","Name","Description","CreatedDate","ModifiedDate") VALUES
            (1,'Synthetic source','Synthetic description',TIMESTAMP '2026-10-07 00:00:00',TIMESTAMP '2026-10-07 00:00:00'),
            (2,'Synthetic target','Synthetic description',TIMESTAMP '2026-10-07 00:00:01',TIMESTAMP '2026-10-07 00:00:01');
        INSERT INTO public."OrderStatusHasPossibleStatus" ("ID","OrderStatusID","PossibleStatusID") VALUES (1,1,2);
        INSERT INTO public."OrderStatusHistory" ("ID","OrderID","OrderStatusID") VALUES (1,84,1);
        """);

    private static async Task MigrateAsync(OrderStatusDbContext context, string target)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await context.GetService<IMigrator>().MigrateAsync(target, lifetime.Token);
    }

    private static async Task ExecuteAsync(OrderStatusDbContext context, string sql)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        await command.ExecuteNonQueryAsync(lifetime.Token);
    }

    private static async Task<T> ScalarAsync<T>(OrderStatusDbContext context, string sql, CancellationToken cancellationToken = default)
    {
        using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lifetime.CancelAfter(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        return (T)(await command.ExecuteScalarAsync(lifetime.Token) ?? throw new InvalidOperationException("Owned scalar query returned no value."));
    }

    private sealed record Snapshot(string Rows, string Schema, string History);
    private static async Task<Snapshot> SnapshotAsync(OrderStatusDbContext context)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var rows = new List<string>();
        foreach (var table in new[] { "OrderStatus", "OrderStatusHasPossibleStatus", "OrderStatusHistory" })
            rows.Add(table + ":" + await ScalarAsync<string>(context, $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') FROM public.{Quote(table)} r", lifetime.Token));
        var schema = await ScalarAsync<string>(context, """
            SELECT jsonb_build_object(
                'columns',(SELECT jsonb_agg(to_jsonb(c) ORDER BY c.table_name,c.ordinal_position) FROM information_schema.columns c WHERE table_schema='public' AND table_name IN ('OrderStatus','OrderStatusHasPossibleStatus','OrderStatusHistory')),
                'constraints',(SELECT jsonb_agg(jsonb_build_object('table',t.relname,'name',c.conname,'definition',pg_get_constraintdef(c.oid),'validated',c.convalidated,'local',c.conislocal,'inherit',c.coninhcount,'noinherit',c.connoinherit) ORDER BY t.relname,c.conname) FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid JOIN pg_namespace n ON n.oid=t.relnamespace WHERE n.nspname='public' AND t.relname IN ('OrderStatus','OrderStatusHasPossibleStatus','OrderStatusHistory')),
                'indexes',(SELECT jsonb_agg(to_jsonb(i) ORDER BY tablename,indexname) FROM pg_indexes i WHERE schemaname='public' AND tablename IN ('OrderStatus','OrderStatusHasPossibleStatus','OrderStatusHistory'))
            )::text
            """, lifetime.Token);
        var history = await ScalarAsync<string>(context, "SELECT COALESCE(jsonb_agg(to_jsonb(h) ORDER BY \"MigrationId\")::text,'[]') FROM public.\"__EFMigrationsHistory\" h", lifetime.Token);
        return new Snapshot(string.Join("\n", rows), schema, history);
    }

    private static string Quote(string identifier) => "\"" + identifier.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
}
