using System.Diagnostics;
using System.Text;
using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Legacy.Maliev.OrderService.Tests.Controllers;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using NpgsqlTypes;

namespace Legacy.Maliev.OrderService.Tests.Data;

public sealed class OrderFileBucketSourceMigrationTests(OrderDeletionReadinessFixture fixture)
    : IClassFixture<OrderDeletionReadinessFixture>
{
    private const string Previous = "20261007200000_PreserveOrderTextSourceLengths";
    private const string Target = "20261007220000_PreserveOrderFileBucketSourceLength";

    [Fact]
    public async Task ModelAndSnapshotRetainRequiredBucketAndIndependentUtf16Check()
    {
        await using var owned = await OpenAsync();
        var context = owned.Context;
        Assert.False(context.Database.HasPendingModelChanges());
        var snapshot = context.GetService<IMigrationsAssembly>().ModelSnapshot;
        Assert.NotNull(snapshot);
        foreach (var model in new[] { context.GetService<IDesignTimeModel>().Model, snapshot.Model })
        {
            var entity = model.FindEntityType(typeof(OrderFile).FullName!);
            Assert.NotNull(entity);
            var name = entity.FindProperty("Bucket");
            Assert.NotNull(name);
            Assert.False(name.IsNullable);
            Assert.Equal(50, name.GetMaxLength());
            Assert.Equal("text", name.GetColumnType());
            var objectName = entity.FindProperty("ObjectName");
            Assert.NotNull(objectName);
            Assert.False(objectName.IsNullable);
            Assert.Null(objectName.GetMaxLength());
            Assert.Equal("text", objectName.GetColumnType());
            Assert.Equal(LengthSql("Bucket", 50), Assert.Single(entity.GetCheckConstraints(), value => value.Name == Check("Bucket")).Sql.Trim());
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task PhysicalUtf16BoundaryPreservesPaddingAndRefusesOverflow(bool supplementary)
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        var exact = supplementary ? string.Concat(Enumerable.Repeat("😀", 24)) + "  " : new string('ก', 48) + "  ";
        Assert.Equal(50, exact.Length);
        await SetAsync(owned.Context, "Bucket", exact);
        Assert.Equal(exact, await ScalarAsync<string>(owned.Context, "SELECT \"Bucket\" FROM public.\"OrderFile\" WHERE \"ID\"=1"));
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => SetAsync(owned.Context, "Bucket", exact + "ก"));
        Assert.Equal("23514", failure.SqlState);
        Assert.Equal(Check("Bucket"), failure.ConstraintName);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }

    [Theory]
    [InlineData("")]
    [InlineData("  ")]
    [InlineData(" ก padded ")]
    public async Task EmptyAndPaddedBucketsSurvivePhysicalWrites(string name)
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        await SetAsync(owned.Context, "Bucket", name);
        Assert.Equal(name, await ScalarAsync<string>(owned.Context, "SELECT \"Bucket\" FROM public.\"OrderFile\" WHERE \"ID\"=1"));
    }

    [Fact]
    public async Task PhysicalNullBucketRefusesWithoutChangingWholeGraph()
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => SetAsync(owned.Context, "Bucket", null));
        Assert.Equal("23502", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }

    [Fact]
    public async Task RetainedSupplementaryOverflowRefusesUpgradeWithoutRewritingRows()
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        var invalid = string.Concat(Enumerable.Repeat("😀", 26));
        Assert.Equal(52, invalid.Length);
        Assert.Equal(26, invalid.EnumerateRunes().Count());
        await SetAsync(owned.Context, "Bucket", invalid);
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }

    [Fact]
    public async Task RowAdmissionRefuses10001ThenAccepts10000WithoutRewritingRows()
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, """
            INSERT INTO public."OrderFile" ("ID","OrderID","Bucket","ObjectName") SELECT value,1,'Synthetic cap row','synthetic.step' FROM generate_series(2,10001) value;
            """);
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
        await ExecuteAsync(owned.Context, "DELETE FROM public.\"OrderFile\" WHERE \"ID\"=10001");
        var admitted = await SnapshotAsync(owned.Context);
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(admitted.Rows, (await SnapshotAsync(owned.Context)).Rows);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task UnexpectedPreimageOrCheckCollisionRefusesAtomicUpgrade(bool collision)
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, collision
            ? "ALTER TABLE public.\"OrderFile\" ADD CONSTRAINT \"CK_OrderFile_Bucket_SourceLength\" CHECK (true)"
            : "ALTER TABLE public.\"OrderFile\" ALTER COLUMN \"Bucket\" TYPE text");
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task MissingOrWrongOwnedCheckRefusesDowngrade(bool wrong)
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, "ALTER TABLE public.\"OrderFile\" DROP CONSTRAINT \"CK_OrderFile_Bucket_SourceLength\"");
        if (wrong) await ExecuteAsync(owned.Context, "ALTER TABLE public.\"OrderFile\" ADD CONSTRAINT \"CK_OrderFile_Bucket_SourceLength\" CHECK (true)");
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Previous));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
        Assert.True(await ScalarAsync<bool>(owned.Context, "SELECT to_regclass('pg_temp.\"__OrderFileBucketSourceGuard\"') IS NULL"));
    }

    [Fact]
    public async Task UpDownUpPreservesWholeGraphForeignKeysIndexesAndSessionTimeouts()
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await SetAsync(owned.Context, "Bucket", string.Concat(Enumerable.Repeat("😀", 24)) + "  ");
        var before = await SnapshotAsync(owned.Context);
        var lockTimeout = await ScalarAsync<string>(owned.Context, "SHOW lock_timeout");
        var statementTimeout = await ScalarAsync<string>(owned.Context, "SHOW statement_timeout");
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(before.Rows, (await SnapshotAsync(owned.Context)).Rows);
        await MigrateAsync(owned.Context, Previous);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(before.Rows, (await SnapshotAsync(owned.Context)).Rows);
        Assert.Equal(lockTimeout, await ScalarAsync<string>(owned.Context, "SHOW lock_timeout"));
        Assert.Equal(statementTimeout, await ScalarAsync<string>(owned.Context, "SHOW statement_timeout"));
        Assert.Null(owned.Context.Database.CurrentTransaction);
        Assert.True(await ScalarAsync<bool>(owned.Context, "SELECT to_regclass('pg_temp.\"__OrderFileBucketSourceGuard\"') IS NULL"));
    }

    [Fact]
    public async Task ContestedWriterLockBoundsOneAttemptAndRestoresItsSession()
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        var before = await SnapshotAsync(owned.Context);
        Assert.True(owned.Context.Database.CreateExecutionStrategy().RetriesOnFailure);
        // One actual SQL lock deadline, not production retry/cancellation acceptance.
        await using var singleAttempt = new OrderDbContext(new DbContextOptionsBuilder<OrderDbContext>()
            .UseNpgsql(owned.Context.Database.GetConnectionString()).Options);
        singleAttempt.Database.SetCommandTimeout(40);
        Assert.False(singleAttempt.Database.CreateExecutionStrategy().RetriesOnFailure);
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await singleAttempt.Database.OpenConnectionAsync(lifetime.Token);
        var session = await FailureSessionAsync(singleAttempt);
        await using var blocker = new NpgsqlConnection(owned.Context.Database.GetConnectionString());
        await blocker.OpenAsync(lifetime.Token);
        await using var transaction = await blocker.BeginTransactionAsync(lifetime.Token);
        try
        {
            await using var command = new NpgsqlCommand("LOCK TABLE public.\"OrderFile\" IN ACCESS EXCLUSIVE MODE", blocker, transaction) { CommandTimeout = 40 };
            await command.ExecuteNonQueryAsync(lifetime.Token);
            var watch = Stopwatch.StartNew();
            var wrapper = await Assert.ThrowsAsync<InvalidOperationException>(() => MigrateAsync(singleAttempt, Target));
            var failure = Assert.IsType<PostgresException>(wrapper.InnerException);
            watch.Stop();
            Assert.Equal("55P03", failure.SqlState);
            Assert.InRange(watch.Elapsed, TimeSpan.FromSeconds(3), TimeSpan.FromSeconds(40));
            await AssertFailureSessionRestoredAsync(singleAttempt, session);
        }
        finally
        {
            using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(45));
            await transaction.RollbackAsync(cleanup.Token);
        }
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(before.Rows, (await SnapshotAsync(owned.Context)).Rows);
    }

    private sealed record FailureSession(string LockTimeout, string StatementTimeout);
    private static async Task<FailureSession> FailureSessionAsync(OrderDbContext context)
    {
        Assert.Null(context.Database.CurrentTransaction);
        return new FailureSession(await ScalarAsync<string>(context, "SHOW lock_timeout"),
            await ScalarAsync<string>(context, "SHOW statement_timeout"));
    }

    private static async Task AssertFailureSessionRestoredAsync(OrderDbContext context, FailureSession expected)
    {
        Assert.Null(context.Database.CurrentTransaction);
        Assert.Equal(expected.LockTimeout, await ScalarAsync<string>(context, "SHOW lock_timeout"));
        Assert.Equal(expected.StatementTimeout, await ScalarAsync<string>(context, "SHOW statement_timeout"));
        Assert.True(await ScalarAsync<bool>(context, "SELECT to_regclass('pg_temp.\"__OrderFileBucketSourceGuard\"') IS NULL"));
    }

    private async Task<OwnedScope> OpenAsync(string? target = null)
    {
        var app = await fixture.AppAsync(null);
        AsyncServiceScope? scope = null;
        try
        {
            scope = app.Services.CreateAsyncScope();
            var context = scope.Value.ServiceProvider.GetRequiredService<OrderDbContext>();
            var authority = new NpgsqlConnectionStringBuilder(context.Database.GetConnectionString());
            var database = authority.Database;
            if (database is null || !database.StartsWith("owned_", StringComparison.Ordinal)
                || !Guid.TryParseExact(database[6..], "N", out _)
                || authority.Host is not ("localhost" or "127.0.0.1") || authority.Pooling)
                throw new InvalidOperationException("Require the fixture-owned isolated order database.");
            context.Database.SetCommandTimeout(40);
            using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
            await context.Database.OpenConnectionAsync(lifetime.Token);
            if (target is not null) await MigrateAsync(context, target);
            return new OwnedScope(app, scope.Value, context);
        }
        catch
        {
            try { if (scope is { } opened) await opened.DisposeAsync(); }
            finally { await app.DisposeAsync(); }
            throw;
        }
    }

    private sealed class OwnedScope(WebApplicationFactory<Program> app, AsyncServiceScope scope, OrderDbContext context) : IAsyncDisposable
    {
        public OrderDbContext Context => context;
        public async ValueTask DisposeAsync()
        {
            try { await scope.DisposeAsync(); }
            finally { await app.DisposeAsync(); }
        }
    }

    private static Task SeedAsync(OrderDbContext context) => ExecuteAsync(context, """
        INSERT INTO public."Category" ("ID","Name") VALUES (1,'Synthetic category');
        INSERT INTO public."FileFormat" ("ID","Name","Extension") VALUES (1,'Synthetic format','.step');
        INSERT INTO public."Process" ("ID","CategoryID","Name","CreatedDate","ModifiedDate") VALUES
            (1,1,'Synthetic process',TIMESTAMP '2026-10-07 00:00:00',TIMESTAMP '2026-10-07 00:00:00');
        INSERT INTO public."Order" ("ID","ProcessID","Quantity","Manufactured","AllowSocialMedia","AllowCancellation","AllowPayment") VALUES (1,1,3,1,false,true,false);
        INSERT INTO public."OrderFile" ("ID","OrderID","Bucket","ObjectName") VALUES (1,1,'synthetic-bucket','synthetic.step');
        """);

    private static Task SetAsync(OrderDbContext context, string field, string? value) => ExecuteAsync(context,
        $"UPDATE public.\"OrderFile\" SET {Quote(field)}=@value WHERE \"ID\"=1",
        new NpgsqlParameter("value", NpgsqlDbType.Text) { Value = (object?)value ?? DBNull.Value, Size = 0 });

    private static async Task MigrateAsync(OrderDbContext context, string target)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await context.GetService<IMigrator>().MigrateAsync(target, lifetime.Token);
    }

    private static async Task ExecuteAsync(OrderDbContext context, string sql, params NpgsqlParameter[] parameters)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        command.Parameters.AddRange(parameters);
        await command.ExecuteNonQueryAsync(lifetime.Token);
    }

    private static async Task<T> ScalarAsync<T>(OrderDbContext context, string sql, CancellationToken cancellationToken = default)
    {
        using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lifetime.CancelAfter(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        return (T)(await command.ExecuteScalarAsync(lifetime.Token) ?? throw new InvalidOperationException("Owned scalar query returned no value."));
    }

    private sealed record Snapshot(string Rows, string Schema, string History);
    private static async Task<Snapshot> SnapshotAsync(OrderDbContext context)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var rows = new List<string>();
        foreach (var table in new[] { "Category", "FileFormat", "Process", "Order", "OrderFile", "OrderDeletionIntent" })
            rows.Add(table + ":" + await ScalarAsync<string>(context, $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') FROM public.{Quote(table)} r", lifetime.Token));
        var schema = await ScalarAsync<string>(context, """
            SELECT jsonb_build_object(
                'columns',(SELECT jsonb_agg(to_jsonb(c) ORDER BY c.table_name,c.ordinal_position) FROM information_schema.columns c WHERE table_schema='public' AND table_name IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent')),
                'constraints',(SELECT jsonb_agg(jsonb_build_object('table',t.relname,'name',c.conname,'definition',pg_get_constraintdef(c.oid),'validated',c.convalidated,'local',c.conislocal,'inherit',c.coninhcount,'noinherit',c.connoinherit) ORDER BY t.relname,c.conname) FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid JOIN pg_namespace n ON n.oid=t.relnamespace WHERE n.nspname='public' AND t.relname IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent')),
                'indexes',(SELECT jsonb_agg(to_jsonb(i) ORDER BY tablename,indexname) FROM pg_indexes i WHERE schemaname='public' AND tablename IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent'))
            )::text
            """, lifetime.Token);
        var history = await ScalarAsync<string>(context, "SELECT COALESCE(jsonb_agg(to_jsonb(h) ORDER BY \"MigrationId\")::text,'[]') FROM public.\"__EFMigrationsHistory\" h", lifetime.Token);
        return new Snapshot(string.Join("\n", rows), schema, history);
    }

    private static string Check(string field) => "CK_OrderFile_" + field + "_SourceLength";
    private static string Quote(string identifier) => "\"" + identifier.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    private static string LengthSql(string field, int maximum) => $"char_length(\"{field}\") + char_length(regexp_replace(\"{field}\" COLLATE \"C\", U&'[\\0001-\\FFFF]', '', 'g')) <= {maximum}";
}
