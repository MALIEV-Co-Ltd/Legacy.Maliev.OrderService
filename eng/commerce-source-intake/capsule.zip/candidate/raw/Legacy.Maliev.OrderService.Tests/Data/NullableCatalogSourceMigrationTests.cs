using Legacy.Maliev.OrderService.Data;
using Legacy.Maliev.OrderService.Domain;
using Legacy.Maliev.OrderService.Tests.Controllers;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using NpgsqlTypes;

namespace Legacy.Maliev.OrderService.Tests.Data;

public sealed class NullableCatalogSourceMigrationTests(OrderDeletionReadinessFixture fixture) : IClassFixture<OrderDeletionReadinessFixture>
{
    private const string Previous = "20261007140000_RequireProcessSourceName";
    private const string Target = "20261007160000_PreserveNullableCatalogSourceLengths";
    public static TheoryData<string, string> Fields => new()
    {
        { "Category", "Name" }, { "FileFormat", "Name" }, { "FileFormat", "Extension" },
    };
    [Fact]
    public async Task ModelAndSnapshotKeepNullabilityAndUtf16Checks()
    {
        await using var owned = await OpenAsync();
        Assert.False(owned.Context.Database.HasPendingModelChanges());
        var snapshot = owned.Context.GetService<IMigrationsAssembly>().ModelSnapshot;
        Assert.NotNull(snapshot);
        foreach (var model in new[] { owned.Context.GetService<IDesignTimeModel>().Model, snapshot.Model })
        {
            foreach (var (type, field) in new[] { (typeof(Category), "Name"), (typeof(FileFormat), "Name"), (typeof(FileFormat), "Extension") })
            {
                var entity = model.FindEntityType(type.FullName!);
                Assert.NotNull(entity);
                var property = entity.FindProperty(field);
                Assert.NotNull(property);
                Assert.True(property.IsNullable);
                Assert.Equal(50, property.GetMaxLength());
                Assert.Equal("text", property.GetColumnType());
                Assert.Equal(LengthSql(field, 50), Assert.Single(entity.GetCheckConstraints(), value => value.Name == Check(type.Name, field)).Sql.Trim());
            }
        }
    }
    public static TheoryData<string, string, bool> Boundaries => new()
    {
        { "Category", "Name", false },
        { "Category", "Name", true },
        { "FileFormat", "Name", false },
        { "FileFormat", "Name", true },
        { "FileFormat", "Extension", false },
        { "FileFormat", "Extension", true },
    };
    [Theory]
    [MemberData(nameof(Boundaries))]
    public async Task PhysicalUtf16BoundaryAndIndependentOverflowRefusal(string table, string field, bool supplementary)
    {
        await using var owned = await OpenAsync();
        var context = owned.Context;
        await SeedAsync(context);
        var exact = supplementary ? string.Concat(Enumerable.Repeat("😀", 24)) + "  " : new string('ก', 48) + "  ";
        Assert.Equal(50, exact.Length);
        await SetAsync(context, table, field, exact);
        Assert.Equal(exact, await ScalarAsync<string>(context, $"SELECT {Quote(field)} FROM public.{Quote(table)} WHERE \"ID\"=1"));
        var before = await SnapshotAsync(context);
        var session = await FailureSessionAsync(context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => SetAsync(context, table, field, exact + "ก"));
        Assert.Equal("23514", failure.SqlState);
        Assert.Equal(Check(table, field), failure.ConstraintName);
        Assert.Equal(before, await SnapshotAsync(context));
        await AssertFailureSessionRestoredAsync(context, session);
    }
    public static TheoryData<string, string, string?> Literals => new()
    {
        { "Category", "Name", null },
        { "Category", "Name", "" },
        { "Category", "Name", "  " },
        { "Category", "Name", " ก padded " },
        { "FileFormat", "Name", null },
        { "FileFormat", "Name", "" },
        { "FileFormat", "Name", "  " },
        { "FileFormat", "Name", " ก padded " },
        { "FileFormat", "Extension", null },
        { "FileFormat", "Extension", "" },
        { "FileFormat", "Extension", "  " },
        { "FileFormat", "Extension", " ก padded " },
    };
    [Theory]
    [MemberData(nameof(Literals))]
    public async Task PhysicalNullEmptyAndPaddingAreLiteral(string table, string field, string? literal)
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        await SetAsync(owned.Context, table, field, literal);
        var actual = await ScalarAsync<string>(owned.Context, $"SELECT COALESCE(to_json({Quote(field)})::text,'null') FROM public.{Quote(table)} WHERE \"ID\"=1");
        // Compare JSON decoded values independently of JSON Unicode escape spelling.
        Assert.Equal(literal, System.Text.Json.JsonSerializer.Deserialize<string?>(actual));
    }
    [Theory]
    [MemberData(nameof(Fields))]
    public async Task RetainedSupplementaryOverflowRefusesWholeUpgrade(string table, string field)
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        var invalid = string.Concat(Enumerable.Repeat("😀", 26));
        Assert.Equal(52, invalid.Length);
        await SetAsync(owned.Context, table, field, invalid);
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }
    [Theory]
    [InlineData("Category")]
    [InlineData("FileFormat")]
    public async Task EachTableRowCapRefuses10001AndAdmits10000(string table)
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, $"INSERT INTO public.{Quote(table)} (\"ID\",\"Name\") SELECT value,'Synthetic cap' FROM generate_series(2,10001) value");
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
        await ExecuteAsync(owned.Context, $"DELETE FROM public.{Quote(table)} WHERE \"ID\"=10001");
        var admitted = await SnapshotAsync(owned.Context);
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(admitted.Rows, (await SnapshotAsync(owned.Context)).Rows);
    }
    public static TheoryData<string, string, bool> Tampering => Boundaries;
    [Theory]
    [MemberData(nameof(Tampering))]
    public async Task UpgradeRefusesWrongNullabilityOrOwnedCheckCollision(string table, string field, bool collision)
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, collision
            ? $"ALTER TABLE public.{Quote(table)} ADD CONSTRAINT {Quote(Check(table, field))} CHECK (true)"
            : $"ALTER TABLE public.{Quote(table)} ALTER COLUMN {Quote(field)} SET NOT NULL");
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Target));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }
    [Theory]
    [MemberData(nameof(Tampering))]
    public async Task DowngradeRefusesMissingOrDifferentOwnedCheck(string table, string field, bool wrong)
    {
        await using var owned = await OpenAsync();
        await SeedAsync(owned.Context);
        await ExecuteAsync(owned.Context, $"ALTER TABLE public.{Quote(table)} DROP CONSTRAINT {Quote(Check(table, field))}");
        if (wrong) await ExecuteAsync(owned.Context, $"ALTER TABLE public.{Quote(table)} ADD CONSTRAINT {Quote(Check(table, field))} CHECK (true)");
        var before = await SnapshotAsync(owned.Context);
        var session = await FailureSessionAsync(owned.Context);
        var failure = await Assert.ThrowsAsync<PostgresException>(() => MigrateAsync(owned.Context, Previous));
        Assert.Equal("P0001", failure.SqlState);
        Assert.Equal(before, await SnapshotAsync(owned.Context));
        await AssertFailureSessionRestoredAsync(owned.Context, session);
    }
    [Fact]
    public async Task UpDownUpPreservesAllRowsAndNullableMetadata()
    {
        await using var owned = await OpenAsync(Previous);
        await SeedAsync(owned.Context);
        await SetAsync(owned.Context, "Category", "Name", null);
        await SetAsync(owned.Context, "FileFormat", "Name", " ก padded ");
        await SetAsync(owned.Context, "FileFormat", "Extension", "");
        var rows = (await SnapshotAsync(owned.Context)).Rows;
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(rows, (await SnapshotAsync(owned.Context)).Rows);
        await MigrateAsync(owned.Context, Previous);
        Assert.Equal(rows, (await SnapshotAsync(owned.Context)).Rows);
        Assert.Equal(3L, await ScalarAsync<long>(owned.Context, "SELECT count(*) FROM information_schema.columns WHERE table_schema='public' AND ((table_name='Category' AND column_name='Name') OR (table_name='FileFormat' AND column_name IN ('Name','Extension'))) AND is_nullable='YES' AND character_maximum_length=50"));
        await MigrateAsync(owned.Context, Target);
        Assert.Equal(rows, (await SnapshotAsync(owned.Context)).Rows);
        Assert.Equal(3L, await ScalarAsync<long>(owned.Context, "SELECT count(*) FROM information_schema.columns WHERE table_schema='public' AND ((table_name='Category' AND column_name='Name') OR (table_name='FileFormat' AND column_name IN ('Name','Extension'))) AND is_nullable='YES' AND data_type='text'"));
    }
    private sealed record FailureSession(string LockTimeout, string StatementTimeout);
    private static async Task<FailureSession> FailureSessionAsync(OrderDbContext context)
    {
        Assert.Null(context.Database.CurrentTransaction);
        return new FailureSession(await ScalarAsync<string>(context, "SHOW lock_timeout"),
            await ScalarAsync<string>(context, "SHOW statement_timeout"));
    }

    private static async Task AssertFailureSessionRestoredAsync(OrderDbContext context, FailureSession expected)
    {
        Assert.Null(context.Database.CurrentTransaction);
        Assert.Equal(expected.LockTimeout, await ScalarAsync<string>(context, "SHOW lock_timeout"));
        Assert.Equal(expected.StatementTimeout, await ScalarAsync<string>(context, "SHOW statement_timeout"));
        Assert.True(await ScalarAsync<bool>(context, "SELECT to_regclass('pg_temp.\"__NullableCatalogSourceGuard\"') IS NULL"));
    }

    private async Task<OwnedScope> OpenAsync(string? target = null)
    {
        var app = await fixture.AppAsync(null);
        AsyncServiceScope? scope = null;
        try
        {
            scope = app.Services.CreateAsyncScope();
            var context = scope.Value.ServiceProvider.GetRequiredService<OrderDbContext>();
            var authority = new NpgsqlConnectionStringBuilder(context.Database.GetConnectionString());
            var database = authority.Database;
            if (database is null || !database.StartsWith("owned_", StringComparison.Ordinal)
                || !Guid.TryParseExact(database[6..], "N", out _)
                || authority.Host is not ("localhost" or "127.0.0.1") || authority.Pooling)
                throw new InvalidOperationException("Require the fixture-owned isolated order database.");
            context.Database.SetCommandTimeout(40);
            using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
            await context.Database.OpenConnectionAsync(lifetime.Token);
            if (target is not null) await MigrateAsync(context, target);
            return new OwnedScope(app, scope.Value, context);
        }
        catch
        {
            try { if (scope is { } opened) await opened.DisposeAsync(); }
            finally { await app.DisposeAsync(); }
            throw;
        }
    }

    private sealed class OwnedScope(WebApplicationFactory<Program> app, AsyncServiceScope scope, OrderDbContext context) : IAsyncDisposable
    {
        public OrderDbContext Context => context;
        public async ValueTask DisposeAsync()
        {
            try { await scope.DisposeAsync(); }
            finally { await app.DisposeAsync(); }
        }
    }

    private static Task SeedAsync(OrderDbContext context) => ExecuteAsync(context, """
        INSERT INTO public."Category" ("ID","Name") VALUES (1,'Synthetic category');
        INSERT INTO public."FileFormat" ("ID","Name","Extension") VALUES (1,'Synthetic format','.step');
        INSERT INTO public."Process" ("ID","CategoryID","Name","CreatedDate","ModifiedDate") VALUES
            (1,1,'Synthetic process',TIMESTAMP '2026-10-07 00:00:00',TIMESTAMP '2026-10-07 00:00:00');
        INSERT INTO public."Order" ("ID","ProcessID","Quantity","Manufactured","AllowSocialMedia","AllowCancellation","AllowPayment") VALUES (1,1,3,1,false,true,false);
        INSERT INTO public."OrderFile" ("ID","OrderID","Bucket","ObjectName") VALUES (1,1,'synthetic-bucket','synthetic.step');
        """);

    private static Task SetAsync(OrderDbContext context, string table, string field, string? value) => ExecuteAsync(context,
        $"UPDATE public.{Quote(table)} SET {Quote(field)}=@value WHERE \"ID\"=1",
        new NpgsqlParameter("value", NpgsqlDbType.Text) { Value = (object?)value ?? DBNull.Value, Size = 0 });

    private static async Task MigrateAsync(OrderDbContext context, string target)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await context.GetService<IMigrator>().MigrateAsync(target, lifetime.Token);
    }

    private static async Task ExecuteAsync(OrderDbContext context, string sql, params NpgsqlParameter[] parameters)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        command.Parameters.AddRange(parameters);
        await command.ExecuteNonQueryAsync(lifetime.Token);
    }

    private static async Task<T> ScalarAsync<T>(OrderDbContext context, string sql, CancellationToken cancellationToken = default)
    {
        using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lifetime.CancelAfter(TimeSpan.FromSeconds(45));
        await using var command = new NpgsqlCommand(sql, (NpgsqlConnection)context.Database.GetDbConnection()) { CommandTimeout = 40 };
        return (T)(await command.ExecuteScalarAsync(lifetime.Token) ?? throw new InvalidOperationException("Owned scalar query returned no value."));
    }

    private sealed record Snapshot(string Rows, string Schema, string History);
    private static async Task<Snapshot> SnapshotAsync(OrderDbContext context)
    {
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(45));
        var rows = new List<string>();
        foreach (var table in new[] { "Category", "FileFormat", "Process", "Order", "OrderFile", "OrderDeletionIntent" })
            rows.Add(table + ":" + await ScalarAsync<string>(context, $"SELECT COALESCE(jsonb_agg(to_jsonb(r) ORDER BY to_jsonb(r)::text)::text,'[]') FROM public.{Quote(table)} r", lifetime.Token));
        var schema = await ScalarAsync<string>(context, """
            SELECT jsonb_build_object(
                'columns',(SELECT jsonb_agg(to_jsonb(c) ORDER BY c.table_name,c.ordinal_position) FROM information_schema.columns c WHERE table_schema='public' AND table_name IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent')),
                'constraints',(SELECT jsonb_agg(jsonb_build_object('table',t.relname,'name',c.conname,'definition',pg_get_constraintdef(c.oid),'validated',c.convalidated,'local',c.conislocal,'inherit',c.coninhcount,'noinherit',c.connoinherit) ORDER BY t.relname,c.conname) FROM pg_constraint c JOIN pg_class t ON t.oid=c.conrelid JOIN pg_namespace n ON n.oid=t.relnamespace WHERE n.nspname='public' AND t.relname IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent')),
                'indexes',(SELECT jsonb_agg(to_jsonb(i) ORDER BY tablename,indexname) FROM pg_indexes i WHERE schemaname='public' AND tablename IN ('Category','FileFormat','Process','Order','OrderFile','OrderDeletionIntent'))
            )::text
            """, lifetime.Token);
        var history = await ScalarAsync<string>(context, "SELECT COALESCE(jsonb_agg(to_jsonb(h) ORDER BY \"MigrationId\")::text,'[]') FROM public.\"__EFMigrationsHistory\" h", lifetime.Token);
        return new Snapshot(string.Join("\n", rows), schema, history);
    }

    private static string Check(string table, string field) => "CK_" + table + "_" + field + "_SourceLength";
    private static string Quote(string identifier) => "\"" + identifier.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"";
    private static string LengthSql(string field, int maximum) => $"char_length(\"{field}\") + char_length(regexp_replace(\"{field}\" COLLATE \"C\", U&'[\\0001-\\FFFF]', '', 'g')) <= {maximum}";
}
